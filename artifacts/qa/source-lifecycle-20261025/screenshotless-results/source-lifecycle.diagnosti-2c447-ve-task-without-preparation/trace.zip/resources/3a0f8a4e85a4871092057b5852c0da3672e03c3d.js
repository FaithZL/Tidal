import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "e2e", "PROD": false, "SSR": false};import * as T from "/node_modules/.vite/deps/three.js?v=749f4ded";
import { OrbitControls } from "/node_modules/.vite/deps/three_addons_controls_OrbitControls__js.js?v=749f4ded";
import { WorldChoreography } from "/src/game/world/choreography.ts";
import { WorldResources, place } from "/src/game/world/resources.ts";
import { Character3D, makeCart, makeLog, makePine } from "/src/game/world/models.ts";
import { buildEnvironment } from "/src/game/world/environment.ts";
import { AdaptiveResolution } from "/src/game/world/adaptiveResolution.ts";
import { NprPalette } from "/src/game/world/nprMaterials.ts";
import { NprCharacter3D, makeNprCart, makeNprLog, makeNprTree } from "/src/game/world/nprModels.ts";
import { buildNprSampleEnvironment } from "/src/game/world/nprEnvironment.ts";
import { loadUserModel } from "/src/game/world/userModel.ts";
import { UserHouseMount } from "/src/game/world/userHouseMount.ts";
import { UserStaticCharacter } from "/src/game/world/userStaticCharacter.ts";
/** Three owns rendering, never business progress. */
export class FarmWorld {
	parent;
	onError;
	scene = new T.Scene();
	camera = new T.PerspectiveCamera(44, 1, .1, 220);
	renderer;
	controls;
	resources = new WorldResources();
	ready;
	palette;
	sampleBadge;
	userHouse;
	userCharacter;
	sample = new URLSearchParams(location.search).get("art") === "npr-sample";
	choreography;
	player;
	npc;
	cart;
	trees = [];
	logs = [];
	chips = [];
	sun = null;
	resolution = new AdaptiveResolution(devicePixelRatio);
	paintedLastFrame = false;
	resizeObserver;
	events = new AbortController();
	subscriptions = [];
	snapshot;
	request = 0;
	lastTime = 0;
	lastPaint = "";
	lastPhase = "home";
	overview = true;
	dirty = true;
	disposed = false;
	lost = false;
	constructor(parent, controller, config, onError) {
		this.parent = parent;
		this.onError = onError;
		this.snapshot = controller.getSnapshot();
		this.choreography = new WorldChoreography(config);
		this.choreography.sync(this.snapshot);
		try {
			this.renderer = new T.WebGLRenderer({
				antialias: true,
				alpha: false,
				powerPreference: "high-performance"
			});
			this.renderer.setPixelRatio(this.resolution.ratio);
			parent.dataset.renderScale = String(this.resolution.ratio);
			this.renderer.outputColorSpace = T.SRGBColorSpace;
			this.renderer.toneMapping = T.ACESFilmicToneMapping;
			this.renderer.toneMappingExposure = 1.03;
			this.renderer.setClearColor(12967137);
			this.renderer.shadowMap.enabled = true;
			this.renderer.shadowMap.type = T.BasicShadowMap;
			this.renderer.domElement.setAttribute("aria-label", "可旋转的三维农场，拖拽旋转、滚轮缩放");
			this.renderer.domElement.tabIndex = 0;
			parent.appendChild(this.renderer.domElement);
			this.scene.background = new T.Color(12967137);
			this.scene.fog = new T.Fog(12967137, 85, 155);
			this.scene.add(new T.HemisphereLight(this.sample ? 15069431 : 14740724, this.sample ? 7902062 : 5466947, this.sample ? 1.6 : 1.1));
			const sun = place(this.scene, new T.DirectionalLight(16772560, 2), -18, 35, 14);
			sun.castShadow = true;
			sun.shadow.mapSize.set(512, 512);
			this.sun = sun;
			sun.shadow.camera.left = -23;
			sun.shadow.camera.right = 55;
			sun.shadow.camera.top = 25;
			sun.shadow.camera.bottom = -25;
			sun.shadow.camera.far = 90;
			sun.shadow.bias = -.001;
			let sampleTextures;
			if (this.sample) {
				parent.dataset.assets = "loading";
				sampleTextures = new Promise((resolve, reject) => {
					let pending = 2, failed = false;
					const loaded = () => {
						if (this.disposed || failed) return;
						if (--pending === 0) resolve();
					};
					const failure = () => {
						if (this.disposed || failed) return;
						failed = true;
						reject(new Error("美术样板贴图加载失败，请重新加载页面"));
					};
					const loader = new T.TextureLoader();
					const atlas = loader.load(`${import.meta.env.BASE_URL}assets/npr/pastoral-atlas-v1.png`, loaded, undefined, failure);
					const leaves = loader.load(`${import.meta.env.BASE_URL}assets/npr/leaf-bough-v2.png`, loaded, undefined, failure);
					this.palette = new NprPalette(this.resources, atlas, leaves);
				});
				this.renderer.setClearColor(11917797);
				this.scene.background = new T.Color(11917797);
				this.scene.fog = new T.Fog(13164515, 24, 86);
				const skyGeometry = this.resources.geometry("npr-sky-dome", () => {
					const geometry = new T.SphereGeometry(160, 24, 16), positions = geometry.getAttribute("position"), colors = [];
					const horizon = new T.Color(11128798), zenith = new T.Color(6729431);
					for (let i = 0; i < positions.count; i++) {
						const color = horizon.clone().lerp(zenith, Math.sqrt(Math.max(0, positions.getY(i) / 160)));
						colors.push(color.r, color.g, color.b);
					}
					geometry.setAttribute("color", new T.Float32BufferAttribute(colors, 3));
					return geometry;
				});
				const sky = new T.Mesh(skyGeometry, this.resources.cachedMaterial("npr-sky", () => new T.MeshBasicMaterial({
					side: T.BackSide,
					vertexColors: true,
					depthWrite: false,
					fog: false
				})));
				sky.renderOrder = -100;
				this.scene.add(sky);
				sun.color.set(16774109);
				sun.intensity = 1.5;
				this.renderer.toneMappingExposure = .98;
				this.renderer.shadowMap.type = T.PCFShadowMap;
				sun.shadow.mapSize.set(1024, 1024);
				sun.shadow.camera.left = -23;
				sun.shadow.camera.right = 28;
				sun.shadow.camera.top = 24;
				sun.shadow.camera.bottom = -24;
				sun.shadow.normalBias = .025;
				this.sampleBadge = document.createElement("span");
				this.sampleBadge.className = "npr-sample-label";
				parent.appendChild(this.sampleBadge);
			}
			this.scene.add(buildEnvironment(this.resources, this.sample ? { excludeSampleZone: true } : undefined));
			if (this.palette) {
				this.scene.add(buildNprSampleEnvironment(this.resources, this.palette, { omitCottage: true }));
				this.userHouse = new UserHouseMount(this.scene, loadUserModel("house", import.meta.env.BASE_URL));
			}
			const prototype = new URLSearchParams(location.search).get("model") === "prototype";
			if (this.palette && !prototype) {
				this.userCharacter = new UserStaticCharacter(loadUserModel("character", import.meta.env.BASE_URL));
				this.player = this.userCharacter;
			} else this.player = this.palette ? new NprCharacter3D(this.resources, this.palette) : new Character3D(this.resources);
			if (this.palette) {
				const comparison = document.createElement("a");
				comparison.href = `${import.meta.env.BASE_URL}?art=npr-sample${prototype ? "" : "&model=prototype"}`;
				comparison.textContent = prototype ? "查看导入人物" : "原动作对照";
				this.sampleBadge.append(prototype ? "原动作人物对照 · 导入房屋 " : "用户人物/房屋 · 人物为无骨骼静态姿态 ", comparison);
				this.ready = Promise.all([
					sampleTextures,
					this.userHouse.ready,
					this.userCharacter?.ready
				]).then(() => {
					if (this.disposed || this.lost) throw new Error("User house loading cancelled");
					parent.dataset.assets = "ready";
					parent.dataset.house = "user-fbx";
					this.dirty = true;
					parent.dataset.character = this.userCharacter ? "user-fbx-static" : "procedural-motion";
				}).catch((error) => {
					if (!this.disposed && !this.lost) {
						parent.dataset.assets = "failed";
						this.userHouse?.dispose();
						this.userCharacter?.dispose();
						const message = error instanceof Error && /美术样板贴图加载失败|用户人物模型加载失败/.test(error.message) ? error.message : "用户房屋模型加载失败，请检查本地模型与贴图后重新加载页面";
						this.reportError(message);
					}
					throw error;
				});
			}
			this.npc = this.palette ? new NprCharacter3D(this.resources, this.palette, true) : new Character3D(this.resources, true);
			this.scene.add(this.player.root, this.npc.root);
			this.npc.root.scale.setScalar(.88);
			this.cart = this.palette ? makeNprCart(this.resources, this.palette) : makeCart(this.resources);
			this.scene.add(this.cart.root);
			for (let i = 0; i < config.treeCount; i++) {
				const tree = this.palette ? makeNprTree(this.resources, this.palette) : makePine(this.resources);
				this.trees.push(tree);
				this.scene.add(tree.root);
			}
			for (let i = 0; i < 8; i++) {
				const chip = this.resources.box(.07, .1, .045, 14988910);
				chip.visible = false;
				this.scene.add(chip);
				this.chips.push(chip);
			}
			this.camera.position.set(43, 42, 57);
			this.controls = new OrbitControls(this.camera, this.renderer.domElement);
			this.controls.target.set(14, 0, 0);
			if (this.sample) {
				this.camera.position.set(8, 5.5, 12);
				this.controls.target.set(-2.5, 1.2, -5);
			}
			this.controls.enableDamping = true;
			this.controls.dampingFactor = .12;
			this.controls.minDistance = this.sample ? 5 : 7;
			this.controls.maxDistance = 85;
			this.controls.minPolarAngle = .3;
			this.controls.maxPolarAngle = Math.PI / 2 - .1;
			this.controls.enablePan = false;
			this.controls.update();
			this.controls.saveState();
			this.controls.addEventListener("change", () => {
				this.dirty = true;
			});
			this.resizeObserver = new ResizeObserver(() => this.resize());
			this.resizeObserver.observe(parent);
			this.resize();
			this.renderer.domElement.addEventListener("webglcontextlost", (e) => {
				e.preventDefault();
				this.lost = true;
				this.controls.enabled = false;
				this.userHouse?.dispose();
				this.userCharacter?.dispose();
				if (this.sample) this.parent.dataset.assets = "failed";
				this.reportError("3D图形上下文已丢失，请重新加载页面后继续");
			}, { signal: this.events.signal });
			this.subscriptions.push(controller.subscribe((s) => {
				this.snapshot = s;
				this.choreography.sync(s);
			}));
			this.subscriptions.push(controller.onEffect((e) => {
				this.snapshot = controller.getSnapshot();
				this.choreography.sync(this.snapshot);
				this.choreography.apply(e);
				// Reset effects precede snapshot subscriptions, so clear presentation state here explicitly.
				if (e.kind === "session-reset") {
					const f = this.choreography.frame;
					this.player.update(f.player, false);
					this.npc.update(f.npc, false);
					this.choreography.setHandAnchor(this.player.handPosition());
				}
				this.dirty = true;
			}));
			parent.dataset.renderer = `Three.js r${T.REVISION}`;
			parent.dataset.art = this.sample ? "tidal-npr-sample-v2" : "tidal-farm-3d-v2";
			const gl = this.renderer.getContext(), debug = gl.getExtension("WEBGL_debug_renderer_info");
			parent.dataset.gpu = debug ? String(gl.getParameter(debug.UNMASKED_RENDERER_WEBGL)) : "WebGL2 renderer unavailable";
			this.request = requestAnimationFrame(this.animate);
		} catch (error) {
			this.destroy(true);
			throw error;
		}
	}
	reportError(message) {
		this.parent.dataset.error = message;
		let error = this.parent.querySelector("#renderError");
		if (!error) {
			error = document.createElement("div");
			error.id = "renderError";
			error.setAttribute("role", "alert");
			this.parent.appendChild(error);
		}
		error.textContent = message;
		this.onError(message);
	}
	resize() {
		const width = this.parent.clientWidth, height = this.parent.clientHeight;
		if (!width || !height) return;
		this.camera.aspect = width / height;
		this.camera.updateProjectionMatrix();
		this.renderer.setSize(width, height, false);
		this.dirty = true;
	}
	animate = (now) => {
		if (this.disposed) return;
		this.request = requestAnimationFrame(this.animate);
		if (this.lost || document.hidden) {
			this.lastTime = 0;
			this.paintedLastFrame = false;
			this.resolution.observe(0, false);
			return;
		}
		const elapsed = this.lastTime ? now - this.lastTime : 0;
		const ratio = this.resolution.observe(elapsed, this.paintedLastFrame && !this.snapshot.pauseReasons.length);
		this.paintedLastFrame = false;
		if (ratio !== this.renderer.getPixelRatio()) {
			this.renderer.setPixelRatio(ratio);
			this.parent.dataset.renderScale = String(ratio);
			this.dirty = true;
		}
		const delta = Math.min(100, elapsed);
		this.lastTime = now;
		this.choreography.advance(delta);
		let f = this.choreography.frame;
		const motionDelta = this.snapshot.pauseReasons.length || elapsed > 100 ? 0 : delta;
		const playerRevision = this.player.visualRevision, npcRevision = this.npc.visualRevision;
		this.player.update(f.player, this.snapshot.task === "chop", motionDelta);
		this.npc.update(f.npc, false, motionDelta);
		if (this.player.visualRevision !== playerRevision || this.npc.visualRevision !== npcRevision) {
			this.dirty = true;
			if (this.sample) this.parent.dataset.motionRevision = String(this.player.visualRevision ?? 0);
		}
		this.choreography.setHandAnchor(this.player.handPosition());
		f = this.choreography.frame;
		const state = this.snapshot, home = state.phase === "home" || state.phase === "setup";
		const phase = home ? "home" : `${state.task}`;
		if (this.lastPhase !== phase) {
			this.lastPhase = phase;
			this.overview = home;
			const offset = this.camera.position.clone().sub(this.controls.target);
			this.controls.target.set(home ? this.sample ? -2.5 : 14 : state.task === "carry" ? f.cart.x : f.player.position.x, home ? this.sample ? 1.2 : 0 : 1, home ? this.sample ? -5 : 0 : state.task === "carry" ? f.cart.z : f.player.position.z);
			if (home) {
				if (this.sample) this.camera.position.set(8, 5.5, 12);
				else this.camera.position.set(43, 42, 57);
			} else this.camera.position.copy(this.controls.target).add(offset.setLength(state.task === "carry" ? 13 : state.task === "load" ? 11 : 12));
			this.dirty = true;
		}
		if (!home && !this.overview && !state.pauseReasons.length) {
			const target = new T.Vector3(state.task === "carry" ? f.cart.x : f.player.position.x, 1, state.task === "carry" ? f.cart.z : f.player.position.z);
			const shift = target.sub(this.controls.target).multiplyScalar(.09);
			if (shift.length() > .002) {
				this.controls.target.add(shift);
				this.camera.position.add(shift);
				this.dirty = true;
			}
		}
		this.controls.update();
		const paint = JSON.stringify(f);
		if (paint !== this.lastPaint) {
			this.lastPaint = paint;
			this.dirty = true;
			this.cart.root.position.set(f.cart.x, f.cart.y, f.cart.z);
			for (const wheel of this.cart.wheels) wheel.rotation.z = -f.cart.x / .35;
			for (let i = 0; i < this.cart.ropes.length; i++) this.cart.ropes[i].visible = f.ropeProgress > i / this.cart.ropes.length;
			f.trees.forEach((t, i) => {
				const tree = this.trees[i];
				tree.root.position.set(t.position.x, t.position.y, t.position.z);
				tree.trunk.visible = !t.felled;
				tree.crown.visible = !t.felled || t.fallProgress < .8;
				tree.crown.rotation.z = t.felled ? -Math.PI / 2 * t.fallProgress : 0;
				tree.crown.scale.setScalar(t.felled ? 1 - t.fallProgress * .5 : 1);
			});
			while (this.logs.length < f.logs.length) {
				const log = this.palette ? makeNprLog(this.resources, this.palette) : makeLog(this.resources);
				this.scene.add(log);
				this.logs.push(log);
			}
			this.logs.forEach((log, i) => {
				const item = f.logs[i];
				log.visible = !!item;
				if (!item) return;
				const p = item.position;
				log.position.set(p.x, p.y, p.z);
				log.rotation.set(item.rotation, item.location === "hand" ? f.player.yaw : Math.PI / 2, 0);
			});
			const hit = f.effects.find((e) => e.kind === "impact" && e.index >= 0), hitTree = hit ? f.trees[hit.index] : null;
			this.chips.forEach((chip, i) => {
				chip.visible = !!hitTree;
				if (!hit || !hitTree) return;
				const a = i * Math.PI / 4, t = hit.progress;
				chip.position.set(hitTree.position.x + Math.cos(a) * t * 1.1, 1.1 + Math.sin(t * Math.PI) * .55 - t * .5, hitTree.position.z + Math.sin(a) * t * 1.1);
				chip.rotation.set(t * 4, a, t * 5);
				chip.scale.setScalar(1 - t * .7);
			});
			this.parent.dataset.particles = hitTree ? "8" : "0";
			const values = {
				action: f.action,
				fallen: String(state.choppedTrees),
				effects: f.effects.map((e) => e.kind).join(","),
				npc: state.phase === "rest" ? state.task === "load" ? "gather" : "secure" : state.phase === "results" ? "celebrate" : state.task === "carry" ? "guide" : "idle",
				inventory: `${state.groundLogs}/${state.cartLogs}/${state.deliveredLogs}`,
				cartPosition: `${f.cart.x.toFixed(3)},${f.cart.z.toFixed(3)}`,
				worldLogs: String(f.logs.length),
				rope: f.ropeProgress.toFixed(3),
				playerMode: f.player.mode
			};
			for (const [key, value] of Object.entries(values)) if (this.parent.dataset[key] !== value) this.parent.dataset[key] = value;
			this.parent.setAttribute("aria-label", `可旋转三维农场。地面${state.groundLogs}、车上${state.cartLogs}、到家${state.deliveredLogs}。${state.pauseReasons.length ? "已暂停" : ""}`);
		}
		if (this.dirty) {
			this.renderer.render(this.scene, this.camera);
			this.dirty = false;
			this.paintedLastFrame = true;
			if (this.sample) this.parent.dataset.hand = this.player.handPosition().toArray().map((n) => n.toFixed(4)).join(",");
			this.parent.dataset.camera = this.camera.position.toArray().map((n) => n.toFixed(3)).join(",");
			const projected = new T.Vector3(-6, 1, 1).project(this.camera);
			this.parent.dataset.probe = projected.toArray().map((n) => n.toFixed(4)).join(",");
		}
	};
	rotate(direction) {
		if (!this.controls.enabled || this.disposed) return;
		const offset = this.camera.position.clone().sub(this.controls.target);
		offset.applyAxisAngle(new T.Vector3(0, 1, 0), direction * .25);
		this.camera.position.copy(this.controls.target).add(offset);
		this.controls.update();
		this.dirty = true;
	}
	resetView() {
		if (this.disposed) return;
		this.overview = true;
		this.controls.reset();
		this.dirty = true;
	}
	setInteractionEnabled(enabled) {
		this.controls.enabled = enabled && !this.lost && !this.disposed;
	}
	destroy(removeCanvas = true) {
		if (this.disposed) return;
		this.disposed = true;
		cancelAnimationFrame(this.request);
		this.events.abort();
		this.resizeObserver?.disconnect();
		this.subscriptions.forEach((stop) => stop());
		this.controls?.dispose();
		this.choreography.dispose();
		this.userHouse?.dispose();
		this.userCharacter?.dispose();
		this.scene.traverse((o) => {
			if (o instanceof T.InstancedMesh) o.dispose();
		});
		this.sun?.shadow.dispose();
		this.scene.clear();
		this.resources.dispose();
		this.renderer?.dispose();
		this.renderer?.forceContextLoss();
		if (removeCanvas) this.renderer?.domElement.remove();
		this.sampleBadge?.remove();
		this.logs = [];
		this.chips = [];
		this.parent.dataset.disposed = "true";
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxPQUFPO0FBQ25CLFNBQVEscUJBQW9CO0FBRzVCLFNBQVEseUJBQXdCO0FBQ2hDLFNBQVEsZ0JBQWUsYUFBWTtBQUNuQyxTQUFRLGFBQVksVUFBUyxTQUFRLGdCQUFlO0FBQ3BELFNBQVEsd0JBQXVCO0FBQy9CLFNBQVEsMEJBQXlCO0FBQ2pDLFNBQVEsa0JBQWlCO0FBQ3pCLFNBQVEsZ0JBQWUsYUFBWSxZQUFXLG1CQUFrQjtBQUNoRSxTQUFRLGlDQUFnQztBQUN4QyxTQUFRLHFCQUFvQjtBQUM1QixTQUFRLHNCQUFxQjtBQUM3QixTQUFRLDJCQUEwQjs7QUFLbEMsT0FBTyxNQUFNLFVBQTZCO0NBV1o7Q0FBNkY7Q0FWMUgsQUFBaUIsUUFBTSxJQUFJLEVBQUUsTUFBTTtDQUFFLEFBQWlCLFNBQU8sSUFBSSxFQUFFLGtCQUFrQixJQUFHLEdBQUUsSUFBRyxHQUFHO0NBQ2hHLEFBQWlCO0NBQXlCLEFBQWlCO0NBQXVCLEFBQWlCLFlBQVUsSUFBSSxlQUFlO0NBQ2hJLEFBQVM7Q0FBcUIsQUFBUTtDQUFvQixBQUFRO0NBQXlCLEFBQVE7Q0FBMEIsQUFBUTtDQUNySSxBQUFpQixTQUFPLElBQUksZ0JBQWdCLFNBQVMsTUFBTSxDQUFDLENBQUMsSUFBSSxLQUFLLE1BQUk7Q0FDMUUsQUFBaUI7Q0FBK0IsQUFBaUI7Q0FBbUIsQUFBaUI7Q0FDckcsQUFBaUI7Q0FBaUMsQUFBaUIsUUFBb0MsQ0FBQztDQUFFLEFBQVEsT0FBZSxDQUFDO0NBQ2xJLEFBQVEsUUFBZSxDQUFDO0NBQUUsQUFBUSxNQUE0QjtDQUM5RCxBQUFpQixhQUFXLElBQUksbUJBQW1CLGdCQUFnQjtDQUFFLEFBQVEsbUJBQWlCO0NBQzlGLEFBQWlCO0NBQThCLEFBQWlCLFNBQU8sSUFBSSxnQkFBZ0I7Q0FBRSxBQUFRLGdCQUEyQixDQUFDO0NBQ2pJLEFBQVE7Q0FBbUMsQUFBUSxVQUFRO0NBQUUsQUFBUSxXQUFTO0NBQUUsQUFBUSxZQUFVO0NBQUcsQUFBUSxZQUFVO0NBQU8sQUFBUSxXQUFTO0NBQUssQUFBUSxRQUFNO0NBQUssQUFBUSxXQUFTO0NBQU0sQUFBUSxPQUFLO0NBQzNNLFlBQVksQUFBaUIsUUFBbUIsWUFBNkIsUUFBNEIsQUFBaUIsU0FBK0I7RUFBNUg7RUFBNkY7RUFDekgsS0FBSyxXQUFTLFdBQVcsWUFBWTtFQUFFLEtBQUssZUFBYSxJQUFJLGtCQUFrQixNQUFNO0VBQUUsS0FBSyxhQUFhLEtBQUssS0FBSyxRQUFRO0VBQzNILElBQUc7R0FDSCxLQUFLLFdBQVMsSUFBSSxFQUFFLGNBQWM7SUFBQyxXQUFVO0lBQUssT0FBTTtJQUFNLGlCQUFnQjtHQUFrQixDQUFDO0dBQ2pHLEtBQUssU0FBUyxjQUFjLEtBQUssV0FBVyxLQUFLO0dBQUUsT0FBTyxRQUFRLGNBQVksT0FBTyxLQUFLLFdBQVcsS0FBSztHQUFFLEtBQUssU0FBUyxtQkFBaUIsRUFBRTtHQUM3SSxLQUFLLFNBQVMsY0FBWSxFQUFFO0dBQXNCLEtBQUssU0FBUyxzQkFBb0I7R0FDcEYsS0FBSyxTQUFTLGNBQWMsUUFBUTtHQUFFLEtBQUssU0FBUyxVQUFVLFVBQVE7R0FBSyxLQUFLLFNBQVMsVUFBVSxPQUFLLEVBQUU7R0FDMUcsS0FBSyxTQUFTLFdBQVcsYUFBYSxjQUFhLG9CQUFvQjtHQUFFLEtBQUssU0FBUyxXQUFXLFdBQVM7R0FBRSxPQUFPLFlBQVksS0FBSyxTQUFTLFVBQVU7R0FDeEosS0FBSyxNQUFNLGFBQVcsSUFBSSxFQUFFLE1BQU0sUUFBUTtHQUFFLEtBQUssTUFBTSxNQUFJLElBQUksRUFBRSxJQUFJLFVBQVMsSUFBRyxHQUFHO0dBQ3BGLEtBQUssTUFBTSxJQUFJLElBQUksRUFBRSxnQkFBZ0IsS0FBSyxTQUFPLFdBQVMsVUFBUyxLQUFLLFNBQU8sVUFBUyxTQUFTLEtBQUssU0FBTyxNQUFJLEdBQUcsQ0FBQztHQUNySCxNQUFNLE1BQUksTUFBTSxLQUFLLE9BQU0sSUFBSSxFQUFFLGlCQUFpQixVQUFTLENBQUMsR0FBRSxDQUFDLElBQUcsSUFBRyxFQUFFO0dBQUUsSUFBSSxhQUFXO0dBQUssSUFBSSxPQUFPLFFBQVEsSUFBSSxLQUFJLEdBQUc7R0FDM0gsS0FBSyxNQUFJO0dBQ1QsSUFBSSxPQUFPLE9BQU8sT0FBSyxDQUFDO0dBQUcsSUFBSSxPQUFPLE9BQU8sUUFBTTtHQUFHLElBQUksT0FBTyxPQUFPLE1BQUk7R0FBRyxJQUFJLE9BQU8sT0FBTyxTQUFPLENBQUM7R0FBRyxJQUFJLE9BQU8sT0FBTyxNQUFJO0dBQUcsSUFBSSxPQUFPLE9BQUssQ0FBQztHQUN0SixJQUFJO0dBQ0osSUFBRyxLQUFLLFFBQU87SUFDZCxPQUFPLFFBQVEsU0FBTztJQUN0QixpQkFBZSxJQUFJLFNBQWUsU0FBUSxXQUFTO0tBQ2xELElBQUksVUFBUSxHQUFFLFNBQU87S0FDckIsTUFBTSxlQUFXO01BQUMsSUFBRyxLQUFLLFlBQVUsUUFBTztNQUFPLElBQUcsRUFBRSxZQUFVLEdBQUUsUUFBUTtLQUFFO0tBQzdFLE1BQU0sZ0JBQVk7TUFBQyxJQUFHLEtBQUssWUFBVSxRQUFPO01BQU8sU0FBTztNQUFLLE9BQU8sSUFBSSxNQUFNLG9CQUFvQixDQUFDO0tBQUU7S0FDdkcsTUFBTSxTQUFPLElBQUksRUFBRSxjQUFjO0tBQ2pDLE1BQU0sUUFBTSxPQUFPLEtBQUssR0FBRyxZQUFZLElBQUksU0FBUyxtQ0FBa0MsUUFBTyxXQUFVLE9BQU87S0FDOUcsTUFBTSxTQUFPLE9BQU8sS0FBSyxHQUFHLFlBQVksSUFBSSxTQUFTLCtCQUE4QixRQUFPLFdBQVUsT0FBTztLQUMzRyxLQUFLLFVBQVEsSUFBSSxXQUFXLEtBQUssV0FBVSxPQUFNLE1BQU07SUFDeEQsQ0FBQztJQUNELEtBQUssU0FBUyxjQUFjLFFBQVE7SUFBRSxLQUFLLE1BQU0sYUFBVyxJQUFJLEVBQUUsTUFBTSxRQUFRO0lBQUUsS0FBSyxNQUFNLE1BQUksSUFBSSxFQUFFLElBQUksVUFBUyxJQUFHLEVBQUU7SUFDekgsTUFBTSxjQUFZLEtBQUssVUFBVSxTQUFTLHNCQUFtQjtLQUM1RCxNQUFNLFdBQVMsSUFBSSxFQUFFLGVBQWUsS0FBSSxJQUFHLEVBQUUsR0FBRSxZQUFVLFNBQVMsYUFBYSxVQUFVLEdBQUUsU0FBZ0IsQ0FBQztLQUM1RyxNQUFNLFVBQVEsSUFBSSxFQUFFLE1BQU0sUUFBUSxHQUFFLFNBQU8sSUFBSSxFQUFFLE1BQU0sT0FBUTtLQUMvRCxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsVUFBVSxPQUFNLEtBQUk7TUFBQyxNQUFNLFFBQU0sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLFFBQU8sS0FBSyxLQUFLLEtBQUssSUFBSSxHQUFFLFVBQVUsS0FBSyxDQUFDLElBQUUsR0FBRyxDQUFDLENBQUM7TUFBRSxPQUFPLEtBQUssTUFBTSxHQUFFLE1BQU0sR0FBRSxNQUFNLENBQUM7S0FBRTtLQUM5SixTQUFTLGFBQWEsU0FBUSxJQUFJLEVBQUUsdUJBQXVCLFFBQU8sQ0FBQyxDQUFDO0tBQUUsT0FBTztJQUM5RSxDQUFDO0lBQ0QsTUFBTSxNQUFJLElBQUksRUFBRSxLQUFLLGFBQVksS0FBSyxVQUFVLGVBQWUsaUJBQWMsSUFBSSxFQUFFLGtCQUFrQjtLQUFDLE1BQUssRUFBRTtLQUFTLGNBQWE7S0FBSyxZQUFXO0tBQU0sS0FBSTtJQUFLLENBQUMsQ0FBQyxDQUFDO0lBQUUsSUFBSSxjQUFZLENBQUM7SUFBSSxLQUFLLE1BQU0sSUFBSSxHQUFHO0lBQzlNLElBQUksTUFBTSxJQUFJLFFBQVE7SUFBRSxJQUFJLFlBQVU7SUFDdEMsS0FBSyxTQUFTLHNCQUFvQjtJQUFJLEtBQUssU0FBUyxVQUFVLE9BQUssRUFBRTtJQUNyRSxJQUFJLE9BQU8sUUFBUSxJQUFJLE1BQUssSUFBSTtJQUFFLElBQUksT0FBTyxPQUFPLE9BQUssQ0FBQztJQUFHLElBQUksT0FBTyxPQUFPLFFBQU07SUFBRyxJQUFJLE9BQU8sT0FBTyxNQUFJO0lBQUcsSUFBSSxPQUFPLE9BQU8sU0FBTyxDQUFDO0lBQUcsSUFBSSxPQUFPLGFBQVc7SUFDcEssS0FBSyxjQUFZLFNBQVMsY0FBYyxNQUFNO0lBQUUsS0FBSyxZQUFZLFlBQVU7SUFBbUIsT0FBTyxZQUFZLEtBQUssV0FBVztHQUNsSTtHQUNBLEtBQUssTUFBTSxJQUFJLGlCQUFpQixLQUFLLFdBQVUsS0FBSyxTQUFPLEVBQUMsbUJBQWtCLEtBQUksSUFBRSxTQUFTLENBQUM7R0FDOUYsSUFBRyxLQUFLLFNBQVE7SUFDZixLQUFLLE1BQU0sSUFBSSwwQkFBMEIsS0FBSyxXQUFVLEtBQUssU0FBUSxFQUFDLGFBQVksS0FBSSxDQUFDLENBQUM7SUFDeEYsS0FBSyxZQUFVLElBQUksZUFBZSxLQUFLLE9BQU0sY0FBYyxTQUFRLFlBQVksSUFBSSxRQUFRLENBQUM7R0FDN0Y7R0FDQSxNQUFNLFlBQVUsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLENBQUMsQ0FBQyxJQUFJLE9BQU8sTUFBSTtHQUNwRSxJQUFHLEtBQUssV0FBUyxDQUFDLFdBQVU7SUFDM0IsS0FBSyxnQkFBYyxJQUFJLG9CQUFvQixjQUFjLGFBQVksWUFBWSxJQUFJLFFBQVEsQ0FBQztJQUFFLEtBQUssU0FBTyxLQUFLO0dBQ2xILE9BQU0sS0FBSyxTQUFPLEtBQUssVUFBUSxJQUFJLGVBQWUsS0FBSyxXQUFVLEtBQUssT0FBTyxJQUFFLElBQUksWUFBWSxLQUFLLFNBQVM7R0FDN0csSUFBRyxLQUFLLFNBQVE7SUFDZixNQUFNLGFBQVcsU0FBUyxjQUFjLEdBQUc7SUFBRSxXQUFXLE9BQUssR0FBRyxZQUFZLElBQUksU0FBUyxpQkFBaUIsWUFBVSxLQUFHO0lBQXFCLFdBQVcsY0FBWSxZQUFVLFdBQVM7SUFDdEwsS0FBSyxZQUFhLE9BQU8sWUFBVSxvQkFBa0IseUJBQXdCLFVBQVU7SUFDdkYsS0FBSyxRQUFNLFFBQVEsSUFBSTtLQUFDO0tBQWUsS0FBSyxVQUFXO0tBQU0sS0FBSyxlQUFlO0lBQUssQ0FBQyxDQUFDLENBQUMsV0FBUztLQUNqRyxJQUFHLEtBQUssWUFBVSxLQUFLLE1BQUssTUFBTSxJQUFJLE1BQU0sOEJBQThCO0tBQUUsT0FBTyxRQUFRLFNBQU87S0FBUSxPQUFPLFFBQVEsUUFBTTtLQUFXLEtBQUssUUFBTTtLQUNySixPQUFPLFFBQVEsWUFBVSxLQUFLLGdCQUFjLG9CQUFrQjtJQUMvRCxDQUFDLENBQUMsQ0FBQyxPQUFPLFVBQWdCO0tBQ3pCLElBQUcsQ0FBQyxLQUFLLFlBQVUsQ0FBQyxLQUFLLE1BQUs7TUFDN0IsT0FBTyxRQUFRLFNBQU87TUFBUyxLQUFLLFdBQVcsUUFBUTtNQUFFLEtBQUssZUFBZSxRQUFRO01BQ3JGLE1BQU0sVUFBUSxpQkFBaUIsU0FBTyx3QkFBd0IsS0FBSyxNQUFNLE9BQU8sSUFBRSxNQUFNLFVBQVE7TUFDaEcsS0FBSyxZQUFZLE9BQU87S0FDekI7S0FDQSxNQUFNO0lBQ1AsQ0FBQztHQUNGO0dBQ0EsS0FBSyxNQUFJLEtBQUssVUFBUSxJQUFJLGVBQWUsS0FBSyxXQUFVLEtBQUssU0FBUSxJQUFJLElBQUUsSUFBSSxZQUFZLEtBQUssV0FBVSxJQUFJO0dBQUUsS0FBSyxNQUFNLElBQUksS0FBSyxPQUFPLE1BQUssS0FBSyxJQUFJLElBQUk7R0FDN0osS0FBSyxJQUFJLEtBQUssTUFBTSxVQUFVLEdBQUc7R0FBRSxLQUFLLE9BQUssS0FBSyxVQUFRLFlBQVksS0FBSyxXQUFVLEtBQUssT0FBTyxJQUFFLFNBQVMsS0FBSyxTQUFTO0dBQUUsS0FBSyxNQUFNLElBQUksS0FBSyxLQUFLLElBQUk7R0FDekosS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLE9BQU8sV0FBVSxLQUFJO0lBQUMsTUFBTSxPQUFLLEtBQUssVUFBUSxZQUFZLEtBQUssV0FBVSxLQUFLLE9BQU8sSUFBRSxTQUFTLEtBQUssU0FBUztJQUFFLEtBQUssTUFBTSxLQUFLLElBQUk7SUFBRSxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUk7R0FBRTtHQUM5SyxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsR0FBRSxLQUFJO0lBQUMsTUFBTSxPQUFLLEtBQUssVUFBVSxJQUFJLEtBQUksSUFBRyxNQUFLLFFBQVE7SUFBRSxLQUFLLFVBQVE7SUFBTSxLQUFLLE1BQU0sSUFBSSxJQUFJO0lBQUUsS0FBSyxNQUFNLEtBQUssSUFBSTtHQUFFO0dBQ3ZJLEtBQUssT0FBTyxTQUFTLElBQUksSUFBRyxJQUFHLEVBQUU7R0FBRSxLQUFLLFdBQVMsSUFBSSxjQUFjLEtBQUssUUFBTyxLQUFLLFNBQVMsVUFBVTtHQUN2RyxLQUFLLFNBQVMsT0FBTyxJQUFJLElBQUcsR0FBRSxDQUFDO0dBQUUsSUFBRyxLQUFLLFFBQU87SUFBQyxLQUFLLE9BQU8sU0FBUyxJQUFJLEdBQUUsS0FBSSxFQUFFO0lBQUUsS0FBSyxTQUFTLE9BQU8sSUFBSSxDQUFDLEtBQUksS0FBSSxDQUFDLENBQUM7R0FBRTtHQUMxSCxLQUFLLFNBQVMsZ0JBQWM7R0FBSyxLQUFLLFNBQVMsZ0JBQWM7R0FBSSxLQUFLLFNBQVMsY0FBWSxLQUFLLFNBQU8sSUFBRTtHQUFFLEtBQUssU0FBUyxjQUFZO0dBQ3JJLEtBQUssU0FBUyxnQkFBYztHQUFHLEtBQUssU0FBUyxnQkFBYyxLQUFLLEtBQUcsSUFBRTtHQUFHLEtBQUssU0FBUyxZQUFVO0dBQU0sS0FBSyxTQUFTLE9BQU87R0FDM0gsS0FBSyxTQUFTLFVBQVU7R0FDeEIsS0FBSyxTQUFTLGlCQUFpQixnQkFBYTtJQUFDLEtBQUssUUFBTTtHQUFLLENBQUM7R0FDOUQsS0FBSyxpQkFBZSxJQUFJLHFCQUFtQixLQUFLLE9BQU8sQ0FBQztHQUFFLEtBQUssZUFBZSxRQUFRLE1BQU07R0FBRSxLQUFLLE9BQU87R0FDMUcsS0FBSyxTQUFTLFdBQVcsaUJBQWlCLHFCQUFtQixNQUFHO0lBQUMsRUFBRSxlQUFlO0lBQUUsS0FBSyxPQUFLO0lBQUssS0FBSyxTQUFTLFVBQVE7SUFBTSxLQUFLLFdBQVcsUUFBUTtJQUFFLEtBQUssZUFBZSxRQUFRO0lBQUUsSUFBRyxLQUFLLFFBQU8sS0FBSyxPQUFPLFFBQVEsU0FBTztJQUFTLEtBQUssWUFBWSx1QkFBdUI7R0FBRSxHQUFFLEVBQUMsUUFBTyxLQUFLLE9BQU8sT0FBTSxDQUFDO0dBQ2pULEtBQUssY0FBYyxLQUFLLFdBQVcsV0FBVSxNQUFHO0lBQUMsS0FBSyxXQUFTO0lBQUUsS0FBSyxhQUFhLEtBQUssQ0FBQztHQUFFLENBQUMsQ0FBQztHQUM3RixLQUFLLGNBQWMsS0FBSyxXQUFXLFVBQVMsTUFBRztJQUM5QyxLQUFLLFdBQVMsV0FBVyxZQUFZO0lBQUUsS0FBSyxhQUFhLEtBQUssS0FBSyxRQUFRO0lBQUUsS0FBSyxhQUFhLE1BQU0sQ0FBQzs7SUFFdEcsSUFBRyxFQUFFLFNBQU8saUJBQWdCO0tBQUMsTUFBTSxJQUFFLEtBQUssYUFBYTtLQUFNLEtBQUssT0FBTyxPQUFPLEVBQUUsUUFBTyxLQUFLO0tBQUUsS0FBSyxJQUFJLE9BQU8sRUFBRSxLQUFJLEtBQUs7S0FBRSxLQUFLLGFBQWEsY0FBYyxLQUFLLE9BQU8sYUFBYSxDQUFDO0lBQUU7SUFDekwsS0FBSyxRQUFNO0dBQ1osQ0FBQyxDQUFDO0dBQ0YsT0FBTyxRQUFRLFdBQVMsYUFBYSxFQUFFO0dBQVcsT0FBTyxRQUFRLE1BQUksS0FBSyxTQUFPLHdCQUFzQjtHQUN2RyxNQUFNLEtBQUcsS0FBSyxTQUFTLFdBQVcsR0FBRSxRQUFNLEdBQUcsYUFBYSwyQkFBMkI7R0FBRSxPQUFPLFFBQVEsTUFBSSxRQUFNLE9BQU8sR0FBRyxhQUFhLE1BQU0sdUJBQXVCLENBQUMsSUFBRTtHQUN2SyxLQUFLLFVBQVEsc0JBQXNCLEtBQUssT0FBTztFQUMvQyxTQUFPLE9BQU07R0FBQyxLQUFLLFFBQVEsSUFBSTtHQUFFLE1BQU07RUFBTTtDQUM5QztDQUNBLEFBQVEsWUFBWSxTQUFvQjtFQUN2QyxLQUFLLE9BQU8sUUFBUSxRQUFNO0VBQzFCLElBQUksUUFBTSxLQUFLLE9BQU8sY0FBMkIsY0FBYztFQUMvRCxJQUFHLENBQUMsT0FBTTtHQUFDLFFBQU0sU0FBUyxjQUFjLEtBQUs7R0FBRSxNQUFNLEtBQUc7R0FBYyxNQUFNLGFBQWEsUUFBTyxPQUFPO0dBQUUsS0FBSyxPQUFPLFlBQVksS0FBSztFQUFFO0VBQ3hJLE1BQU0sY0FBWTtFQUFRLEtBQUssUUFBUSxPQUFPO0NBQy9DO0NBQ0EsQUFBUSxTQUFhO0VBQUMsTUFBTSxRQUFNLEtBQUssT0FBTyxhQUFZLFNBQU8sS0FBSyxPQUFPO0VBQWEsSUFBRyxDQUFDLFNBQU8sQ0FBQyxRQUFPO0VBQU8sS0FBSyxPQUFPLFNBQU8sUUFBTTtFQUFPLEtBQUssT0FBTyx1QkFBdUI7RUFBRSxLQUFLLFNBQVMsUUFBUSxPQUFNLFFBQU8sS0FBSztFQUFFLEtBQUssUUFBTTtDQUFLO0NBQ25QLEFBQVEsV0FBUyxRQUFrQjtFQUNsQyxJQUFHLEtBQUssVUFBUztFQUFPLEtBQUssVUFBUSxzQkFBc0IsS0FBSyxPQUFPO0VBQ3ZFLElBQUcsS0FBSyxRQUFNLFNBQVMsUUFBTztHQUFDLEtBQUssV0FBUztHQUFFLEtBQUssbUJBQWlCO0dBQU0sS0FBSyxXQUFXLFFBQVEsR0FBRSxLQUFLO0dBQUU7RUFBTztFQUNuSCxNQUFNLFVBQVEsS0FBSyxXQUFTLE1BQUksS0FBSyxXQUFTO0VBQzlDLE1BQU0sUUFBTSxLQUFLLFdBQVcsUUFBUSxTQUFRLEtBQUssb0JBQWtCLENBQUMsS0FBSyxTQUFTLGFBQWEsTUFBTTtFQUFFLEtBQUssbUJBQWlCO0VBQzdILElBQUcsVUFBUSxLQUFLLFNBQVMsY0FBYyxHQUFFO0dBQUMsS0FBSyxTQUFTLGNBQWMsS0FBSztHQUFFLEtBQUssT0FBTyxRQUFRLGNBQVksT0FBTyxLQUFLO0dBQUUsS0FBSyxRQUFNO0VBQUs7RUFDM0ksTUFBTSxRQUFNLEtBQUssSUFBSSxLQUFJLE9BQU87RUFBRSxLQUFLLFdBQVM7RUFBSSxLQUFLLGFBQWEsUUFBUSxLQUFLO0VBQ25GLElBQUksSUFBRSxLQUFLLGFBQWE7RUFBTSxNQUFNLGNBQVksS0FBSyxTQUFTLGFBQWEsVUFBUSxVQUFRLE1BQUksSUFBRTtFQUNqRyxNQUFNLGlCQUFlLEtBQUssT0FBTyxnQkFBZSxjQUFZLEtBQUssSUFBSTtFQUNyRSxLQUFLLE9BQU8sT0FBTyxFQUFFLFFBQU8sS0FBSyxTQUFTLFNBQU8sUUFBTyxXQUFXO0VBQUUsS0FBSyxJQUFJLE9BQU8sRUFBRSxLQUFJLE9BQU0sV0FBVztFQUM1RyxJQUFHLEtBQUssT0FBTyxtQkFBaUIsa0JBQWdCLEtBQUssSUFBSSxtQkFBaUIsYUFBWTtHQUNyRixLQUFLLFFBQU07R0FBSyxJQUFHLEtBQUssUUFBTyxLQUFLLE9BQU8sUUFBUSxpQkFBZSxPQUFPLEtBQUssT0FBTyxrQkFBZ0IsQ0FBQztFQUN2RztFQUNBLEtBQUssYUFBYSxjQUFjLEtBQUssT0FBTyxhQUFhLENBQUM7RUFBRSxJQUFFLEtBQUssYUFBYTtFQUNoRixNQUFNLFFBQU0sS0FBSyxVQUFTLE9BQUssTUFBTSxVQUFRLFVBQVEsTUFBTSxVQUFRO0VBQ25FLE1BQU0sUUFBTSxPQUFLLFNBQU8sR0FBRyxNQUFNO0VBQ2pDLElBQUcsS0FBSyxjQUFZLE9BQU07R0FDekIsS0FBSyxZQUFVO0dBQU0sS0FBSyxXQUFTO0dBQUssTUFBTSxTQUFPLEtBQUssT0FBTyxTQUFTLE1BQU0sQ0FBQyxDQUFDLElBQUksS0FBSyxTQUFTLE1BQU07R0FDMUcsS0FBSyxTQUFTLE9BQU8sSUFBSSxPQUFNLEtBQUssU0FBTyxDQUFDLE1BQUksS0FBSSxNQUFNLFNBQU8sVUFBUSxFQUFFLEtBQUssSUFBRSxFQUFFLE9BQU8sU0FBUyxHQUFFLE9BQU0sS0FBSyxTQUFPLE1BQUksSUFBRyxHQUFFLE9BQU0sS0FBSyxTQUFPLENBQUMsSUFBRSxJQUFHLE1BQU0sU0FBTyxVQUFRLEVBQUUsS0FBSyxJQUFFLEVBQUUsT0FBTyxTQUFTLENBQUM7R0FDMU0sSUFBRyxNQUFLO0lBQUMsSUFBRyxLQUFLLFFBQU8sS0FBSyxPQUFPLFNBQVMsSUFBSSxHQUFFLEtBQUksRUFBRTtTQUFPLEtBQUssT0FBTyxTQUFTLElBQUksSUFBRyxJQUFHLEVBQUU7R0FBRSxPQUFNLEtBQUssT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLE1BQU0sQ0FBQyxDQUFDLElBQUksT0FBTyxVQUFVLE1BQU0sU0FBTyxVQUFRLEtBQUcsTUFBTSxTQUFPLFNBQU8sS0FBRyxFQUFFLENBQUM7R0FBRSxLQUFLLFFBQU07RUFDOU87RUFDQSxJQUFHLENBQUMsUUFBTSxDQUFDLEtBQUssWUFBVSxDQUFDLE1BQU0sYUFBYSxRQUFPO0dBQUMsTUFBTSxTQUFPLElBQUksRUFBRSxRQUFRLE1BQU0sU0FBTyxVQUFRLEVBQUUsS0FBSyxJQUFFLEVBQUUsT0FBTyxTQUFTLEdBQUUsR0FBRSxNQUFNLFNBQU8sVUFBUSxFQUFFLEtBQUssSUFBRSxFQUFFLE9BQU8sU0FBUyxDQUFDO0dBQUUsTUFBTSxRQUFNLE9BQU8sSUFBSSxLQUFLLFNBQVMsTUFBTSxDQUFDLENBQUMsZUFBZSxHQUFHO0dBQUUsSUFBRyxNQUFNLE9BQU8sSUFBRSxNQUFLO0lBQUMsS0FBSyxTQUFTLE9BQU8sSUFBSSxLQUFLO0lBQUUsS0FBSyxPQUFPLFNBQVMsSUFBSSxLQUFLO0lBQUUsS0FBSyxRQUFNO0dBQUs7RUFBQztFQUNsVyxLQUFLLFNBQVMsT0FBTztFQUNyQixNQUFNLFFBQU0sS0FBSyxVQUFVLENBQUM7RUFBRSxJQUFHLFVBQVEsS0FBSyxXQUFVO0dBQ3ZELEtBQUssWUFBVTtHQUFNLEtBQUssUUFBTTtHQUFLLEtBQUssS0FBSyxLQUFLLFNBQVMsSUFBSSxFQUFFLEtBQUssR0FBRSxFQUFFLEtBQUssR0FBRSxFQUFFLEtBQUssQ0FBQztHQUMzRixLQUFJLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBTyxNQUFNLFNBQVMsSUFBRSxDQUFDLEVBQUUsS0FBSyxJQUFFO0dBQy9ELEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxLQUFLLEtBQUssTUFBTSxRQUFPLEtBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxDQUFDLFVBQVEsRUFBRSxlQUFjLElBQUUsS0FBSyxLQUFLLE1BQU07R0FDdEcsRUFBRSxNQUFNLFNBQVMsR0FBRSxNQUFJO0lBQ3RCLE1BQU0sT0FBSyxLQUFLLE1BQU07SUFBRyxLQUFLLEtBQUssU0FBUyxJQUFJLEVBQUUsU0FBUyxHQUFFLEVBQUUsU0FBUyxHQUFFLEVBQUUsU0FBUyxDQUFDO0lBQUUsS0FBSyxNQUFNLFVBQVEsQ0FBQyxFQUFFO0lBQzlHLEtBQUssTUFBTSxVQUFRLENBQUMsRUFBRSxVQUFRLEVBQUUsZUFBYTtJQUFHLEtBQUssTUFBTSxTQUFTLElBQUUsRUFBRSxTQUFPLENBQUMsS0FBSyxLQUFHLElBQUUsRUFBRSxlQUFhO0lBQ3pHLEtBQUssTUFBTSxNQUFNLFVBQVUsRUFBRSxTQUFPLElBQUUsRUFBRSxlQUFhLEtBQUcsQ0FBQztHQUMxRCxDQUFDO0dBQ0QsT0FBTSxLQUFLLEtBQUssU0FBTyxFQUFFLEtBQUssUUFBTztJQUFDLE1BQU0sTUFBSSxLQUFLLFVBQVEsV0FBVyxLQUFLLFdBQVUsS0FBSyxPQUFPLElBQUUsUUFBUSxLQUFLLFNBQVM7SUFBRSxLQUFLLE1BQU0sSUFBSSxHQUFHO0lBQUUsS0FBSyxLQUFLLEtBQUssR0FBRztHQUFFO0dBQ3JLLEtBQUssS0FBSyxTQUFTLEtBQUksTUFBSTtJQUFDLE1BQU0sT0FBSyxFQUFFLEtBQUs7SUFBRyxJQUFJLFVBQVEsQ0FBQyxDQUFDO0lBQUssSUFBRyxDQUFDLE1BQUs7SUFBTyxNQUFNLElBQUUsS0FBSztJQUFTLElBQUksU0FBUyxJQUFJLEVBQUUsR0FBRSxFQUFFLEdBQUUsRUFBRSxDQUFDO0lBQUUsSUFBSSxTQUFTLElBQUksS0FBSyxVQUFTLEtBQUssYUFBVyxTQUFPLEVBQUUsT0FBTyxNQUFJLEtBQUssS0FBRyxHQUFFLENBQUM7R0FBRSxDQUFDO0dBQ3pOLE1BQU0sTUFBSSxFQUFFLFFBQVEsTUFBSyxNQUFHLEVBQUUsU0FBTyxZQUFVLEVBQUUsU0FBTyxDQUFDLEdBQUUsVUFBUSxNQUFJLEVBQUUsTUFBTSxJQUFJLFNBQU87R0FDMUYsS0FBSyxNQUFNLFNBQVMsTUFBSyxNQUFJO0lBQUMsS0FBSyxVQUFRLENBQUMsQ0FBQztJQUFRLElBQUcsQ0FBQyxPQUFLLENBQUMsU0FBUTtJQUFPLE1BQU0sSUFBRSxJQUFFLEtBQUssS0FBRyxHQUFFLElBQUUsSUFBSTtJQUFTLEtBQUssU0FBUyxJQUFJLFFBQVEsU0FBUyxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsSUFBRSxLQUFJLE1BQUksS0FBSyxJQUFJLElBQUUsS0FBSyxFQUFFLElBQUUsTUFBSSxJQUFFLElBQUcsUUFBUSxTQUFTLElBQUUsS0FBSyxJQUFJLENBQUMsSUFBRSxJQUFFLEdBQUc7SUFBRSxLQUFLLFNBQVMsSUFBSSxJQUFFLEdBQUUsR0FBRSxJQUFFLENBQUM7SUFBRSxLQUFLLE1BQU0sVUFBVSxJQUFFLElBQUUsRUFBRTtHQUFFLENBQUM7R0FDMVMsS0FBSyxPQUFPLFFBQVEsWUFBVSxVQUFRLE1BQUk7R0FDMUMsTUFBTSxTQUFPO0lBQUMsUUFBTyxFQUFFO0lBQU8sUUFBTyxPQUFPLE1BQU0sWUFBWTtJQUFFLFNBQVEsRUFBRSxRQUFRLEtBQUksTUFBRyxFQUFFLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRztJQUFFLEtBQUksTUFBTSxVQUFRLFNBQVEsTUFBTSxTQUFPLFNBQU8sV0FBUyxXQUFVLE1BQU0sVUFBUSxZQUFVLGNBQVksTUFBTSxTQUFPLFVBQVEsVUFBUTtJQUFPLFdBQVUsR0FBRyxNQUFNLFdBQVcsR0FBRyxNQUFNLFNBQVMsR0FBRyxNQUFNO0lBQWdCLGNBQWEsR0FBRyxFQUFFLEtBQUssRUFBRSxRQUFRLENBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLFFBQVEsQ0FBQztJQUFJLFdBQVUsT0FBTyxFQUFFLEtBQUssTUFBTTtJQUFFLE1BQUssRUFBRSxhQUFhLFFBQVEsQ0FBQztJQUFFLFlBQVcsRUFBRSxPQUFPO0dBQUk7R0FDamQsS0FBSSxNQUFLLENBQUMsS0FBSSxVQUFTLE9BQU8sUUFBUSxNQUFNLEdBQUUsSUFBRyxLQUFLLE9BQU8sUUFBUSxTQUFPLE9BQU0sS0FBSyxPQUFPLFFBQVEsT0FBSztHQUMzRyxLQUFLLE9BQU8sYUFBYSxjQUFhLGFBQWEsTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLEtBQUssTUFBTSxjQUFjLEdBQUcsTUFBTSxhQUFhLFNBQU8sUUFBTSxJQUFJO0VBQ3pKO0VBQ0EsSUFBRyxLQUFLLE9BQU07R0FDYixLQUFLLFNBQVMsT0FBTyxLQUFLLE9BQU0sS0FBSyxNQUFNO0dBQUUsS0FBSyxRQUFNO0dBQU0sS0FBSyxtQkFBaUI7R0FDcEYsSUFBRyxLQUFLLFFBQU8sS0FBSyxPQUFPLFFBQVEsT0FBSyxLQUFLLE9BQU8sYUFBYSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSSxNQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRztHQUMxRyxLQUFLLE9BQU8sUUFBUSxTQUFPLEtBQUssT0FBTyxTQUFTLFFBQVEsQ0FBQyxDQUFDLEtBQUksTUFBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FDdkYsTUFBTSxZQUFVLElBQUksRUFBRSxRQUFRLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxNQUFNO0dBQUUsS0FBSyxPQUFPLFFBQVEsUUFBTSxVQUFVLFFBQVEsQ0FBQyxDQUFDLEtBQUksTUFBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFDdkk7Q0FDRDtDQUNBLE9BQU8sV0FBc0I7RUFBQyxJQUFHLENBQUMsS0FBSyxTQUFTLFdBQVMsS0FBSyxVQUFTO0VBQU8sTUFBTSxTQUFPLEtBQUssT0FBTyxTQUFTLE1BQU0sQ0FBQyxDQUFDLElBQUksS0FBSyxTQUFTLE1BQU07RUFBRSxPQUFPLGVBQWUsSUFBSSxFQUFFLFFBQVEsR0FBRSxHQUFFLENBQUMsR0FBRSxZQUFVLEdBQUc7RUFBRSxLQUFLLE9BQU8sU0FBUyxLQUFLLEtBQUssU0FBUyxNQUFNLENBQUMsQ0FBQyxJQUFJLE1BQU07RUFBRSxLQUFLLFNBQVMsT0FBTztFQUFFLEtBQUssUUFBTTtDQUFLO0NBQy9TLFlBQWdCO0VBQUMsSUFBRyxLQUFLLFVBQVM7RUFBTyxLQUFLLFdBQVM7RUFBSyxLQUFLLFNBQVMsTUFBTTtFQUFFLEtBQUssUUFBTTtDQUFLO0NBQ2xHLHNCQUFzQixTQUFxQjtFQUFDLEtBQUssU0FBUyxVQUFRLFdBQVMsQ0FBQyxLQUFLLFFBQU0sQ0FBQyxLQUFLO0NBQVM7Q0FDdEcsUUFBUSxlQUFhLE1BQVU7RUFDOUIsSUFBRyxLQUFLLFVBQVM7RUFBTyxLQUFLLFdBQVM7RUFBSyxxQkFBcUIsS0FBSyxPQUFPO0VBQUUsS0FBSyxPQUFPLE1BQU07RUFBRSxLQUFLLGdCQUFnQixXQUFXO0VBQUUsS0FBSyxjQUFjLFNBQVEsU0FBTSxLQUFLLENBQUM7RUFDM0ssS0FBSyxVQUFVLFFBQVE7RUFBRSxLQUFLLGFBQWEsUUFBUTtFQUFFLEtBQUssV0FBVyxRQUFRO0VBQUUsS0FBSyxlQUFlLFFBQVE7RUFBRSxLQUFLLE1BQU0sVUFBUyxNQUFHO0dBQUMsSUFBRyxhQUFhLEVBQUUsZUFBYyxFQUFFLFFBQVE7RUFBRSxDQUFDO0VBQUUsS0FBSyxLQUFLLE9BQU8sUUFBUTtFQUFFLEtBQUssTUFBTSxNQUFNO0VBQUUsS0FBSyxVQUFVLFFBQVE7RUFBRSxLQUFLLFVBQVUsUUFBUTtFQUFFLEtBQUssVUFBVSxpQkFBaUI7RUFDcFQsSUFBRyxjQUFhLEtBQUssVUFBVSxXQUFXLE9BQU87RUFBRSxLQUFLLGFBQWEsT0FBTztFQUFFLEtBQUssT0FBSyxDQUFDO0VBQUUsS0FBSyxRQUFNLENBQUM7RUFBRSxLQUFLLE9BQU8sUUFBUSxXQUFTO0NBQ3ZJO0FBQ0QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRmFybVdvcmxkLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFQgZnJvbSAndGhyZWUnO1xuaW1wb3J0IHtPcmJpdENvbnRyb2xzfSBmcm9tICd0aHJlZS9hZGRvbnMvY29udHJvbHMvT3JiaXRDb250cm9scy5qcyc7XG5pbXBvcnQgdHlwZSB7RGVtb0NvbmZpZ30gZnJvbSAnLi4vLi4vY29uZmlnL2RlbW9Db25maWcuanMnO1xuaW1wb3J0IHR5cGUge1Nlc3Npb25Db250cm9sbGVyLFNlc3Npb25TbmFwc2hvdH0gZnJvbSAnLi4vLi4vZG9tYWluL3R5cGVzLmpzJztcbmltcG9ydCB7V29ybGRDaG9yZW9ncmFwaHl9IGZyb20gJy4vY2hvcmVvZ3JhcGh5LmpzJztcbmltcG9ydCB7V29ybGRSZXNvdXJjZXMscGxhY2V9IGZyb20gJy4vcmVzb3VyY2VzLmpzJztcbmltcG9ydCB7Q2hhcmFjdGVyM0QsbWFrZUNhcnQsbWFrZUxvZyxtYWtlUGluZX0gZnJvbSAnLi9tb2RlbHMuanMnO1xuaW1wb3J0IHtidWlsZEVudmlyb25tZW50fSBmcm9tICcuL2Vudmlyb25tZW50LmpzJztcbmltcG9ydCB7QWRhcHRpdmVSZXNvbHV0aW9ufSBmcm9tICcuL2FkYXB0aXZlUmVzb2x1dGlvbi5qcyc7XG5pbXBvcnQge05wclBhbGV0dGV9IGZyb20gJy4vbnByTWF0ZXJpYWxzLmpzJztcbmltcG9ydCB7TnByQ2hhcmFjdGVyM0QsbWFrZU5wckNhcnQsbWFrZU5wckxvZyxtYWtlTnByVHJlZX0gZnJvbSAnLi9ucHJNb2RlbHMuanMnO1xuaW1wb3J0IHtidWlsZE5wclNhbXBsZUVudmlyb25tZW50fSBmcm9tICcuL25wckVudmlyb25tZW50LmpzJztcbmltcG9ydCB7bG9hZFVzZXJNb2RlbH0gZnJvbSAnLi91c2VyTW9kZWwuanMnO1xuaW1wb3J0IHtVc2VySG91c2VNb3VudH0gZnJvbSAnLi91c2VySG91c2VNb3VudC5qcyc7XG5pbXBvcnQge1VzZXJTdGF0aWNDaGFyYWN0ZXJ9IGZyb20gJy4vdXNlclN0YXRpY0NoYXJhY3Rlci5qcyc7XG5pbXBvcnQgdHlwZSB7V29ybGRBY3Rvcn0gZnJvbSAnLi90eXBlcy5qcyc7XG5leHBvcnQgaW50ZXJmYWNlIEdhbWVWaWV3e3JlYWRvbmx5IHJlYWR5PzpQcm9taXNlPHZvaWQ+O2Rlc3Ryb3kocmVtb3ZlQ2FudmFzPzpib29sZWFuKTp2b2lkO3JvdGF0ZShkaXJlY3Rpb246bnVtYmVyKTp2b2lkO3Jlc2V0VmlldygpOnZvaWQ7c2V0SW50ZXJhY3Rpb25FbmFibGVkKGVuYWJsZWQ6Ym9vbGVhbik6dm9pZH1cbmludGVyZmFjZSBWaXN1YWxBY3RvcntyZWFkb25seSByb290OlQuR3JvdXA7cmVhZG9ubHkgdmlzdWFsUmV2aXNpb24/Om51bWJlcjt1cGRhdGUoYWN0b3I6V29ybGRBY3RvcixjaG9wcGluZzpib29sZWFuLGRlbHRhTXM/Om51bWJlcik6dm9pZDtoYW5kUG9zaXRpb24oKTpULlZlY3RvcjN9XG4vKiogVGhyZWUgb3ducyByZW5kZXJpbmcsIG5ldmVyIGJ1c2luZXNzIHByb2dyZXNzLiAqL1xuZXhwb3J0IGNsYXNzIEZhcm1Xb3JsZCBpbXBsZW1lbnRzIEdhbWVWaWV3e1xuIHByaXZhdGUgcmVhZG9ubHkgc2NlbmU9bmV3IFQuU2NlbmUoKTtwcml2YXRlIHJlYWRvbmx5IGNhbWVyYT1uZXcgVC5QZXJzcGVjdGl2ZUNhbWVyYSg0NCwxLC4xLDIyMCk7XG4gcHJpdmF0ZSByZWFkb25seSByZW5kZXJlcjpULldlYkdMUmVuZGVyZXI7cHJpdmF0ZSByZWFkb25seSBjb250cm9sczpPcmJpdENvbnRyb2xzO3ByaXZhdGUgcmVhZG9ubHkgcmVzb3VyY2VzPW5ldyBXb3JsZFJlc291cmNlcygpO1xuIHJlYWRvbmx5IHJlYWR5PzpQcm9taXNlPHZvaWQ+O3ByaXZhdGUgcGFsZXR0ZT86TnByUGFsZXR0ZTtwcml2YXRlIHNhbXBsZUJhZGdlPzpIVE1MRWxlbWVudDtwcml2YXRlIHVzZXJIb3VzZT86VXNlckhvdXNlTW91bnQ7cHJpdmF0ZSB1c2VyQ2hhcmFjdGVyPzpVc2VyU3RhdGljQ2hhcmFjdGVyO1xuIHByaXZhdGUgcmVhZG9ubHkgc2FtcGxlPW5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKS5nZXQoJ2FydCcpPT09J25wci1zYW1wbGUnO1xuIHByaXZhdGUgcmVhZG9ubHkgY2hvcmVvZ3JhcGh5OldvcmxkQ2hvcmVvZ3JhcGh5O3ByaXZhdGUgcmVhZG9ubHkgcGxheWVyOlZpc3VhbEFjdG9yO3ByaXZhdGUgcmVhZG9ubHkgbnBjOlZpc3VhbEFjdG9yO1xuIHByaXZhdGUgcmVhZG9ubHkgY2FydDpSZXR1cm5UeXBlPHR5cGVvZiBtYWtlQ2FydD47cHJpdmF0ZSByZWFkb25seSB0cmVlczpSZXR1cm5UeXBlPHR5cGVvZiBtYWtlUGluZT5bXT1bXTtwcml2YXRlIGxvZ3M6VC5Hcm91cFtdPVtdO1xuIHByaXZhdGUgY2hpcHM6VC5NZXNoW109W107cHJpdmF0ZSBzdW46VC5EaXJlY3Rpb25hbExpZ2h0fG51bGw9bnVsbDtcbiBwcml2YXRlIHJlYWRvbmx5IHJlc29sdXRpb249bmV3IEFkYXB0aXZlUmVzb2x1dGlvbihkZXZpY2VQaXhlbFJhdGlvKTtwcml2YXRlIHBhaW50ZWRMYXN0RnJhbWU9ZmFsc2U7XG4gcHJpdmF0ZSByZWFkb25seSByZXNpemVPYnNlcnZlcjpSZXNpemVPYnNlcnZlcjtwcml2YXRlIHJlYWRvbmx5IGV2ZW50cz1uZXcgQWJvcnRDb250cm9sbGVyKCk7cHJpdmF0ZSBzdWJzY3JpcHRpb25zOigoKT0+dm9pZClbXT1bXTtcbiBwcml2YXRlIHNuYXBzaG90OlJlYWRvbmx5PFNlc3Npb25TbmFwc2hvdD47cHJpdmF0ZSByZXF1ZXN0PTA7cHJpdmF0ZSBsYXN0VGltZT0wO3ByaXZhdGUgbGFzdFBhaW50PScnO3ByaXZhdGUgbGFzdFBoYXNlPSdob21lJztwcml2YXRlIG92ZXJ2aWV3PXRydWU7cHJpdmF0ZSBkaXJ0eT10cnVlO3ByaXZhdGUgZGlzcG9zZWQ9ZmFsc2U7cHJpdmF0ZSBsb3N0PWZhbHNlO1xuIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcGFyZW50OkhUTUxFbGVtZW50LGNvbnRyb2xsZXI6U2Vzc2lvbkNvbnRyb2xsZXIsY29uZmlnOlJlYWRvbmx5PERlbW9Db25maWc+LHByaXZhdGUgcmVhZG9ubHkgb25FcnJvcjoobWVzc2FnZTpzdHJpbmcpPT52b2lkKXtcbiAgdGhpcy5zbmFwc2hvdD1jb250cm9sbGVyLmdldFNuYXBzaG90KCk7dGhpcy5jaG9yZW9ncmFwaHk9bmV3IFdvcmxkQ2hvcmVvZ3JhcGh5KGNvbmZpZyk7dGhpcy5jaG9yZW9ncmFwaHkuc3luYyh0aGlzLnNuYXBzaG90KTtcbiAgdHJ5e1xuICB0aGlzLnJlbmRlcmVyPW5ldyBULldlYkdMUmVuZGVyZXIoe2FudGlhbGlhczp0cnVlLGFscGhhOmZhbHNlLHBvd2VyUHJlZmVyZW5jZTonaGlnaC1wZXJmb3JtYW5jZSd9KTtcbiAgdGhpcy5yZW5kZXJlci5zZXRQaXhlbFJhdGlvKHRoaXMucmVzb2x1dGlvbi5yYXRpbyk7cGFyZW50LmRhdGFzZXQucmVuZGVyU2NhbGU9U3RyaW5nKHRoaXMucmVzb2x1dGlvbi5yYXRpbyk7dGhpcy5yZW5kZXJlci5vdXRwdXRDb2xvclNwYWNlPVQuU1JHQkNvbG9yU3BhY2U7XG4gIHRoaXMucmVuZGVyZXIudG9uZU1hcHBpbmc9VC5BQ0VTRmlsbWljVG9uZU1hcHBpbmc7dGhpcy5yZW5kZXJlci50b25lTWFwcGluZ0V4cG9zdXJlPTEuMDM7XG4gIHRoaXMucmVuZGVyZXIuc2V0Q2xlYXJDb2xvcigweGM1ZGNlMSk7dGhpcy5yZW5kZXJlci5zaGFkb3dNYXAuZW5hYmxlZD10cnVlO3RoaXMucmVuZGVyZXIuc2hhZG93TWFwLnR5cGU9VC5CYXNpY1NoYWRvd01hcDtcbiAgdGhpcy5yZW5kZXJlci5kb21FbGVtZW50LnNldEF0dHJpYnV0ZSgnYXJpYS1sYWJlbCcsJ+WPr+aXi+i9rOeahOS4iee7tOWGnOWcuu+8jOaLluaLveaXi+i9rOOAgea7mui9rue8qeaUvicpO3RoaXMucmVuZGVyZXIuZG9tRWxlbWVudC50YWJJbmRleD0wO3BhcmVudC5hcHBlbmRDaGlsZCh0aGlzLnJlbmRlcmVyLmRvbUVsZW1lbnQpO1xuICB0aGlzLnNjZW5lLmJhY2tncm91bmQ9bmV3IFQuQ29sb3IoMHhjNWRjZTEpO3RoaXMuc2NlbmUuZm9nPW5ldyBULkZvZygweGM1ZGNlMSw4NSwxNTUpO1xuICB0aGlzLnNjZW5lLmFkZChuZXcgVC5IZW1pc3BoZXJlTGlnaHQodGhpcy5zYW1wbGU/MHhlNWYwZjc6MHhlMGVjZjQsdGhpcy5zYW1wbGU/MHg3ODkzNmU6MHg1MzZiNDMsdGhpcy5zYW1wbGU/MS42OjEuMSkpO1xuICBjb25zdCBzdW49cGxhY2UodGhpcy5zY2VuZSxuZXcgVC5EaXJlY3Rpb25hbExpZ2h0KDB4ZmZlZGQwLDIpLC0xOCwzNSwxNCk7c3VuLmNhc3RTaGFkb3c9dHJ1ZTtzdW4uc2hhZG93Lm1hcFNpemUuc2V0KDUxMiw1MTIpO1xuICB0aGlzLnN1bj1zdW47XG4gIHN1bi5zaGFkb3cuY2FtZXJhLmxlZnQ9LTIzO3N1bi5zaGFkb3cuY2FtZXJhLnJpZ2h0PTU1O3N1bi5zaGFkb3cuY2FtZXJhLnRvcD0yNTtzdW4uc2hhZG93LmNhbWVyYS5ib3R0b209LTI1O3N1bi5zaGFkb3cuY2FtZXJhLmZhcj05MDtzdW4uc2hhZG93LmJpYXM9LS4wMDE7XG4gIGxldCBzYW1wbGVUZXh0dXJlczpQcm9taXNlPHZvaWQ+fHVuZGVmaW5lZDtcbiAgaWYodGhpcy5zYW1wbGUpe1xuICAgcGFyZW50LmRhdGFzZXQuYXNzZXRzPSdsb2FkaW5nJztcbiAgIHNhbXBsZVRleHR1cmVzPW5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLHJlamVjdCk9PntcbiAgICBsZXQgcGVuZGluZz0yLGZhaWxlZD1mYWxzZTtcbiAgICBjb25zdCBsb2FkZWQ9KCk9PntpZih0aGlzLmRpc3Bvc2VkfHxmYWlsZWQpcmV0dXJuO2lmKC0tcGVuZGluZz09PTApcmVzb2x2ZSgpO307XG4gICAgY29uc3QgZmFpbHVyZT0oKT0+e2lmKHRoaXMuZGlzcG9zZWR8fGZhaWxlZClyZXR1cm47ZmFpbGVkPXRydWU7cmVqZWN0KG5ldyBFcnJvcign576O5pyv5qC35p2/6LS05Zu+5Yqg6L295aSx6LSl77yM6K+36YeN5paw5Yqg6L296aG16Z2iJykpO307XG4gICAgY29uc3QgbG9hZGVyPW5ldyBULlRleHR1cmVMb2FkZXIoKTtcbiAgICBjb25zdCBhdGxhcz1sb2FkZXIubG9hZChgJHtpbXBvcnQubWV0YS5lbnYuQkFTRV9VUkx9YXNzZXRzL25wci9wYXN0b3JhbC1hdGxhcy12MS5wbmdgLGxvYWRlZCx1bmRlZmluZWQsZmFpbHVyZSk7XG4gICAgY29uc3QgbGVhdmVzPWxvYWRlci5sb2FkKGAke2ltcG9ydC5tZXRhLmVudi5CQVNFX1VSTH1hc3NldHMvbnByL2xlYWYtYm91Z2gtdjIucG5nYCxsb2FkZWQsdW5kZWZpbmVkLGZhaWx1cmUpO1xuICAgIHRoaXMucGFsZXR0ZT1uZXcgTnByUGFsZXR0ZSh0aGlzLnJlc291cmNlcyxhdGxhcyxsZWF2ZXMpO1xuICAgfSk7XG4gICB0aGlzLnJlbmRlcmVyLnNldENsZWFyQ29sb3IoMHhiNWQ5ZTUpO3RoaXMuc2NlbmUuYmFja2dyb3VuZD1uZXcgVC5Db2xvcigweGI1ZDllNSk7dGhpcy5zY2VuZS5mb2c9bmV3IFQuRm9nKDB4YzhkZmUzLDI0LDg2KTtcbiAgIGNvbnN0IHNreUdlb21ldHJ5PXRoaXMucmVzb3VyY2VzLmdlb21ldHJ5KCducHItc2t5LWRvbWUnLCgpPT57XG4gICAgY29uc3QgZ2VvbWV0cnk9bmV3IFQuU3BoZXJlR2VvbWV0cnkoMTYwLDI0LDE2KSxwb3NpdGlvbnM9Z2VvbWV0cnkuZ2V0QXR0cmlidXRlKCdwb3NpdGlvbicpLGNvbG9yczpudW1iZXJbXT1bXTtcbiAgICBjb25zdCBob3Jpem9uPW5ldyBULkNvbG9yKDB4YTljZmRlKSx6ZW5pdGg9bmV3IFQuQ29sb3IoMHg2NmFlZDcpO1xuICAgIGZvcihsZXQgaT0wO2k8cG9zaXRpb25zLmNvdW50O2krKyl7Y29uc3QgY29sb3I9aG9yaXpvbi5jbG9uZSgpLmxlcnAoemVuaXRoLE1hdGguc3FydChNYXRoLm1heCgwLHBvc2l0aW9ucy5nZXRZKGkpLzE2MCkpKTtjb2xvcnMucHVzaChjb2xvci5yLGNvbG9yLmcsY29sb3IuYik7fVxuICAgIGdlb21ldHJ5LnNldEF0dHJpYnV0ZSgnY29sb3InLG5ldyBULkZsb2F0MzJCdWZmZXJBdHRyaWJ1dGUoY29sb3JzLDMpKTtyZXR1cm4gZ2VvbWV0cnk7XG4gICB9KTtcbiAgIGNvbnN0IHNreT1uZXcgVC5NZXNoKHNreUdlb21ldHJ5LHRoaXMucmVzb3VyY2VzLmNhY2hlZE1hdGVyaWFsKCducHItc2t5JywoKT0+bmV3IFQuTWVzaEJhc2ljTWF0ZXJpYWwoe3NpZGU6VC5CYWNrU2lkZSx2ZXJ0ZXhDb2xvcnM6dHJ1ZSxkZXB0aFdyaXRlOmZhbHNlLGZvZzpmYWxzZX0pKSk7c2t5LnJlbmRlck9yZGVyPS0xMDA7dGhpcy5zY2VuZS5hZGQoc2t5KTtcbiAgIHN1bi5jb2xvci5zZXQoMHhmZmYzZGQpO3N1bi5pbnRlbnNpdHk9MS41O1xuICAgdGhpcy5yZW5kZXJlci50b25lTWFwcGluZ0V4cG9zdXJlPS45ODt0aGlzLnJlbmRlcmVyLnNoYWRvd01hcC50eXBlPVQuUENGU2hhZG93TWFwO1xuICAgc3VuLnNoYWRvdy5tYXBTaXplLnNldCgxMDI0LDEwMjQpO3N1bi5zaGFkb3cuY2FtZXJhLmxlZnQ9LTIzO3N1bi5zaGFkb3cuY2FtZXJhLnJpZ2h0PTI4O3N1bi5zaGFkb3cuY2FtZXJhLnRvcD0yNDtzdW4uc2hhZG93LmNhbWVyYS5ib3R0b209LTI0O3N1bi5zaGFkb3cubm9ybWFsQmlhcz0uMDI1O1xuICAgdGhpcy5zYW1wbGVCYWRnZT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7dGhpcy5zYW1wbGVCYWRnZS5jbGFzc05hbWU9J25wci1zYW1wbGUtbGFiZWwnO3BhcmVudC5hcHBlbmRDaGlsZCh0aGlzLnNhbXBsZUJhZGdlKTtcbiAgfVxuICB0aGlzLnNjZW5lLmFkZChidWlsZEVudmlyb25tZW50KHRoaXMucmVzb3VyY2VzLHRoaXMuc2FtcGxlP3tleGNsdWRlU2FtcGxlWm9uZTp0cnVlfTp1bmRlZmluZWQpKTtcbiAgaWYodGhpcy5wYWxldHRlKXtcbiAgIHRoaXMuc2NlbmUuYWRkKGJ1aWxkTnByU2FtcGxlRW52aXJvbm1lbnQodGhpcy5yZXNvdXJjZXMsdGhpcy5wYWxldHRlLHtvbWl0Q290dGFnZTp0cnVlfSkpO1xuICAgdGhpcy51c2VySG91c2U9bmV3IFVzZXJIb3VzZU1vdW50KHRoaXMuc2NlbmUsbG9hZFVzZXJNb2RlbCgnaG91c2UnLGltcG9ydC5tZXRhLmVudi5CQVNFX1VSTCkpO1xuICB9XG4gIGNvbnN0IHByb3RvdHlwZT1uZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLnNlYXJjaCkuZ2V0KCdtb2RlbCcpPT09J3Byb3RvdHlwZSc7XG4gIGlmKHRoaXMucGFsZXR0ZSYmIXByb3RvdHlwZSl7XG4gICB0aGlzLnVzZXJDaGFyYWN0ZXI9bmV3IFVzZXJTdGF0aWNDaGFyYWN0ZXIobG9hZFVzZXJNb2RlbCgnY2hhcmFjdGVyJyxpbXBvcnQubWV0YS5lbnYuQkFTRV9VUkwpKTt0aGlzLnBsYXllcj10aGlzLnVzZXJDaGFyYWN0ZXI7XG4gIH1lbHNlIHRoaXMucGxheWVyPXRoaXMucGFsZXR0ZT9uZXcgTnByQ2hhcmFjdGVyM0QodGhpcy5yZXNvdXJjZXMsdGhpcy5wYWxldHRlKTpuZXcgQ2hhcmFjdGVyM0QodGhpcy5yZXNvdXJjZXMpO1xuICBpZih0aGlzLnBhbGV0dGUpe1xuICAgY29uc3QgY29tcGFyaXNvbj1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7Y29tcGFyaXNvbi5ocmVmPWAke2ltcG9ydC5tZXRhLmVudi5CQVNFX1VSTH0/YXJ0PW5wci1zYW1wbGUke3Byb3RvdHlwZT8nJzonJm1vZGVsPXByb3RvdHlwZSd9YDtjb21wYXJpc29uLnRleHRDb250ZW50PXByb3RvdHlwZT8n5p+l55yL5a+85YWl5Lq654mpJzon5Y6f5Yqo5L2c5a+554WnJztcbiAgIHRoaXMuc2FtcGxlQmFkZ2UhLmFwcGVuZChwcm90b3R5cGU/J+WOn+WKqOS9nOS6uueJqeWvueeFpyDCtyDlr7zlhaXmiL/lsYsgJzon55So5oi35Lq654mpL+aIv+WxiyDCtyDkurrniankuLrml6DpqqjpqrzpnZnmgIHlp7/mgIEgJyxjb21wYXJpc29uKTtcbiAgIHRoaXMucmVhZHk9UHJvbWlzZS5hbGwoW3NhbXBsZVRleHR1cmVzLHRoaXMudXNlckhvdXNlIS5yZWFkeSx0aGlzLnVzZXJDaGFyYWN0ZXI/LnJlYWR5XSkudGhlbigoKT0+e1xuICAgIGlmKHRoaXMuZGlzcG9zZWR8fHRoaXMubG9zdCl0aHJvdyBuZXcgRXJyb3IoJ1VzZXIgaG91c2UgbG9hZGluZyBjYW5jZWxsZWQnKTtwYXJlbnQuZGF0YXNldC5hc3NldHM9J3JlYWR5JztwYXJlbnQuZGF0YXNldC5ob3VzZT0ndXNlci1mYngnO3RoaXMuZGlydHk9dHJ1ZTtcbiAgICBwYXJlbnQuZGF0YXNldC5jaGFyYWN0ZXI9dGhpcy51c2VyQ2hhcmFjdGVyPyd1c2VyLWZieC1zdGF0aWMnOidwcm9jZWR1cmFsLW1vdGlvbic7XG4gICB9KS5jYXRjaCgoZXJyb3I6dW5rbm93bik9PntcbiAgICBpZighdGhpcy5kaXNwb3NlZCYmIXRoaXMubG9zdCl7XG4gICAgIHBhcmVudC5kYXRhc2V0LmFzc2V0cz0nZmFpbGVkJzt0aGlzLnVzZXJIb3VzZT8uZGlzcG9zZSgpO3RoaXMudXNlckNoYXJhY3Rlcj8uZGlzcG9zZSgpO1xuICAgICBjb25zdCBtZXNzYWdlPWVycm9yIGluc3RhbmNlb2YgRXJyb3ImJi/nvo7mnK/moLfmnb/otLTlm77liqDovb3lpLHotKV855So5oi35Lq654mp5qih5Z6L5Yqg6L295aSx6LSlLy50ZXN0KGVycm9yLm1lc3NhZ2UpP2Vycm9yLm1lc3NhZ2U6J+eUqOaIt+aIv+Wxi+aooeWei+WKoOi9veWksei0pe+8jOivt+ajgOafpeacrOWcsOaooeWei+S4jui0tOWbvuWQjumHjeaWsOWKoOi9vemhtemdoic7XG4gICAgIHRoaXMucmVwb3J0RXJyb3IobWVzc2FnZSk7XG4gICAgfVxuICAgIHRocm93IGVycm9yO1xuICAgfSk7XG4gIH1cbiAgdGhpcy5ucGM9dGhpcy5wYWxldHRlP25ldyBOcHJDaGFyYWN0ZXIzRCh0aGlzLnJlc291cmNlcyx0aGlzLnBhbGV0dGUsdHJ1ZSk6bmV3IENoYXJhY3RlcjNEKHRoaXMucmVzb3VyY2VzLHRydWUpO3RoaXMuc2NlbmUuYWRkKHRoaXMucGxheWVyLnJvb3QsdGhpcy5ucGMucm9vdCk7XG4gIHRoaXMubnBjLnJvb3Quc2NhbGUuc2V0U2NhbGFyKC44OCk7dGhpcy5jYXJ0PXRoaXMucGFsZXR0ZT9tYWtlTnByQ2FydCh0aGlzLnJlc291cmNlcyx0aGlzLnBhbGV0dGUpOm1ha2VDYXJ0KHRoaXMucmVzb3VyY2VzKTt0aGlzLnNjZW5lLmFkZCh0aGlzLmNhcnQucm9vdCk7XG4gIGZvcihsZXQgaT0wO2k8Y29uZmlnLnRyZWVDb3VudDtpKyspe2NvbnN0IHRyZWU9dGhpcy5wYWxldHRlP21ha2VOcHJUcmVlKHRoaXMucmVzb3VyY2VzLHRoaXMucGFsZXR0ZSk6bWFrZVBpbmUodGhpcy5yZXNvdXJjZXMpO3RoaXMudHJlZXMucHVzaCh0cmVlKTt0aGlzLnNjZW5lLmFkZCh0cmVlLnJvb3QpO31cbiAgZm9yKGxldCBpPTA7aTw4O2krKyl7Y29uc3QgY2hpcD10aGlzLnJlc291cmNlcy5ib3goLjA3LC4xLC4wNDUsMHhlNGI2NmUpO2NoaXAudmlzaWJsZT1mYWxzZTt0aGlzLnNjZW5lLmFkZChjaGlwKTt0aGlzLmNoaXBzLnB1c2goY2hpcCk7fVxuICB0aGlzLmNhbWVyYS5wb3NpdGlvbi5zZXQoNDMsNDIsNTcpO3RoaXMuY29udHJvbHM9bmV3IE9yYml0Q29udHJvbHModGhpcy5jYW1lcmEsdGhpcy5yZW5kZXJlci5kb21FbGVtZW50KTtcbiAgdGhpcy5jb250cm9scy50YXJnZXQuc2V0KDE0LDAsMCk7aWYodGhpcy5zYW1wbGUpe3RoaXMuY2FtZXJhLnBvc2l0aW9uLnNldCg4LDUuNSwxMik7dGhpcy5jb250cm9scy50YXJnZXQuc2V0KC0yLjUsMS4yLC01KTt9XG4gIHRoaXMuY29udHJvbHMuZW5hYmxlRGFtcGluZz10cnVlO3RoaXMuY29udHJvbHMuZGFtcGluZ0ZhY3Rvcj0uMTI7dGhpcy5jb250cm9scy5taW5EaXN0YW5jZT10aGlzLnNhbXBsZT81Ojc7dGhpcy5jb250cm9scy5tYXhEaXN0YW5jZT04NTtcbiAgdGhpcy5jb250cm9scy5taW5Qb2xhckFuZ2xlPS4zO3RoaXMuY29udHJvbHMubWF4UG9sYXJBbmdsZT1NYXRoLlBJLzItLjE7dGhpcy5jb250cm9scy5lbmFibGVQYW49ZmFsc2U7dGhpcy5jb250cm9scy51cGRhdGUoKTtcbiAgdGhpcy5jb250cm9scy5zYXZlU3RhdGUoKTtcbiAgdGhpcy5jb250cm9scy5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCgpPT57dGhpcy5kaXJ0eT10cnVlO30pO1xuICB0aGlzLnJlc2l6ZU9ic2VydmVyPW5ldyBSZXNpemVPYnNlcnZlcigoKT0+dGhpcy5yZXNpemUoKSk7dGhpcy5yZXNpemVPYnNlcnZlci5vYnNlcnZlKHBhcmVudCk7dGhpcy5yZXNpemUoKTtcbiAgdGhpcy5yZW5kZXJlci5kb21FbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3dlYmdsY29udGV4dGxvc3QnLGU9PntlLnByZXZlbnREZWZhdWx0KCk7dGhpcy5sb3N0PXRydWU7dGhpcy5jb250cm9scy5lbmFibGVkPWZhbHNlO3RoaXMudXNlckhvdXNlPy5kaXNwb3NlKCk7dGhpcy51c2VyQ2hhcmFjdGVyPy5kaXNwb3NlKCk7aWYodGhpcy5zYW1wbGUpdGhpcy5wYXJlbnQuZGF0YXNldC5hc3NldHM9J2ZhaWxlZCc7dGhpcy5yZXBvcnRFcnJvcignM0Tlm77lvaLkuIrkuIvmloflt7LkuKLlpLHvvIzor7fph43mlrDliqDovb3pobXpnaLlkI7nu6fnu60nKTt9LHtzaWduYWw6dGhpcy5ldmVudHMuc2lnbmFsfSk7XG4gIHRoaXMuc3Vic2NyaXB0aW9ucy5wdXNoKGNvbnRyb2xsZXIuc3Vic2NyaWJlKHM9Pnt0aGlzLnNuYXBzaG90PXM7dGhpcy5jaG9yZW9ncmFwaHkuc3luYyhzKTt9KSk7XG4gIHRoaXMuc3Vic2NyaXB0aW9ucy5wdXNoKGNvbnRyb2xsZXIub25FZmZlY3QoZT0+e1xuICAgdGhpcy5zbmFwc2hvdD1jb250cm9sbGVyLmdldFNuYXBzaG90KCk7dGhpcy5jaG9yZW9ncmFwaHkuc3luYyh0aGlzLnNuYXBzaG90KTt0aGlzLmNob3Jlb2dyYXBoeS5hcHBseShlKTtcbiAgIC8vIFJlc2V0IGVmZmVjdHMgcHJlY2VkZSBzbmFwc2hvdCBzdWJzY3JpcHRpb25zLCBzbyBjbGVhciBwcmVzZW50YXRpb24gc3RhdGUgaGVyZSBleHBsaWNpdGx5LlxuICAgaWYoZS5raW5kPT09J3Nlc3Npb24tcmVzZXQnKXtjb25zdCBmPXRoaXMuY2hvcmVvZ3JhcGh5LmZyYW1lO3RoaXMucGxheWVyLnVwZGF0ZShmLnBsYXllcixmYWxzZSk7dGhpcy5ucGMudXBkYXRlKGYubnBjLGZhbHNlKTt0aGlzLmNob3Jlb2dyYXBoeS5zZXRIYW5kQW5jaG9yKHRoaXMucGxheWVyLmhhbmRQb3NpdGlvbigpKTt9XG4gICB0aGlzLmRpcnR5PXRydWU7XG4gIH0pKTtcbiAgcGFyZW50LmRhdGFzZXQucmVuZGVyZXI9YFRocmVlLmpzIHIke1QuUkVWSVNJT059YDtwYXJlbnQuZGF0YXNldC5hcnQ9dGhpcy5zYW1wbGU/J3RpZGFsLW5wci1zYW1wbGUtdjInOid0aWRhbC1mYXJtLTNkLXYyJztcbiAgY29uc3QgZ2w9dGhpcy5yZW5kZXJlci5nZXRDb250ZXh0KCksZGVidWc9Z2wuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9kZWJ1Z19yZW5kZXJlcl9pbmZvJyk7cGFyZW50LmRhdGFzZXQuZ3B1PWRlYnVnP1N0cmluZyhnbC5nZXRQYXJhbWV0ZXIoZGVidWcuVU5NQVNLRURfUkVOREVSRVJfV0VCR0wpKTonV2ViR0wyIHJlbmRlcmVyIHVuYXZhaWxhYmxlJztcbiAgdGhpcy5yZXF1ZXN0PXJlcXVlc3RBbmltYXRpb25GcmFtZSh0aGlzLmFuaW1hdGUpO1xuICB9Y2F0Y2goZXJyb3Ipe3RoaXMuZGVzdHJveSh0cnVlKTt0aHJvdyBlcnJvcjt9XG4gfVxuIHByaXZhdGUgcmVwb3J0RXJyb3IobWVzc2FnZTpzdHJpbmcpOnZvaWR7XG4gIHRoaXMucGFyZW50LmRhdGFzZXQuZXJyb3I9bWVzc2FnZTtcbiAgbGV0IGVycm9yPXRoaXMucGFyZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KCcjcmVuZGVyRXJyb3InKTtcbiAgaWYoIWVycm9yKXtlcnJvcj1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtlcnJvci5pZD0ncmVuZGVyRXJyb3InO2Vycm9yLnNldEF0dHJpYnV0ZSgncm9sZScsJ2FsZXJ0Jyk7dGhpcy5wYXJlbnQuYXBwZW5kQ2hpbGQoZXJyb3IpO31cbiAgZXJyb3IudGV4dENvbnRlbnQ9bWVzc2FnZTt0aGlzLm9uRXJyb3IobWVzc2FnZSk7XG4gfVxuIHByaXZhdGUgcmVzaXplKCk6dm9pZHtjb25zdCB3aWR0aD10aGlzLnBhcmVudC5jbGllbnRXaWR0aCxoZWlnaHQ9dGhpcy5wYXJlbnQuY2xpZW50SGVpZ2h0O2lmKCF3aWR0aHx8IWhlaWdodClyZXR1cm47dGhpcy5jYW1lcmEuYXNwZWN0PXdpZHRoL2hlaWdodDt0aGlzLmNhbWVyYS51cGRhdGVQcm9qZWN0aW9uTWF0cml4KCk7dGhpcy5yZW5kZXJlci5zZXRTaXplKHdpZHRoLGhlaWdodCxmYWxzZSk7dGhpcy5kaXJ0eT10cnVlO31cbiBwcml2YXRlIGFuaW1hdGU9KG5vdzpudW1iZXIpOnZvaWQ9PntcbiAgaWYodGhpcy5kaXNwb3NlZClyZXR1cm47dGhpcy5yZXF1ZXN0PXJlcXVlc3RBbmltYXRpb25GcmFtZSh0aGlzLmFuaW1hdGUpO1xuICBpZih0aGlzLmxvc3R8fGRvY3VtZW50LmhpZGRlbil7dGhpcy5sYXN0VGltZT0wO3RoaXMucGFpbnRlZExhc3RGcmFtZT1mYWxzZTt0aGlzLnJlc29sdXRpb24ub2JzZXJ2ZSgwLGZhbHNlKTtyZXR1cm47fVxuICBjb25zdCBlbGFwc2VkPXRoaXMubGFzdFRpbWU/bm93LXRoaXMubGFzdFRpbWU6MDtcbiAgY29uc3QgcmF0aW89dGhpcy5yZXNvbHV0aW9uLm9ic2VydmUoZWxhcHNlZCx0aGlzLnBhaW50ZWRMYXN0RnJhbWUmJiF0aGlzLnNuYXBzaG90LnBhdXNlUmVhc29ucy5sZW5ndGgpO3RoaXMucGFpbnRlZExhc3RGcmFtZT1mYWxzZTtcbiAgaWYocmF0aW8hPT10aGlzLnJlbmRlcmVyLmdldFBpeGVsUmF0aW8oKSl7dGhpcy5yZW5kZXJlci5zZXRQaXhlbFJhdGlvKHJhdGlvKTt0aGlzLnBhcmVudC5kYXRhc2V0LnJlbmRlclNjYWxlPVN0cmluZyhyYXRpbyk7dGhpcy5kaXJ0eT10cnVlO31cbiAgY29uc3QgZGVsdGE9TWF0aC5taW4oMTAwLGVsYXBzZWQpO3RoaXMubGFzdFRpbWU9bm93O3RoaXMuY2hvcmVvZ3JhcGh5LmFkdmFuY2UoZGVsdGEpO1xuICBsZXQgZj10aGlzLmNob3Jlb2dyYXBoeS5mcmFtZTtjb25zdCBtb3Rpb25EZWx0YT10aGlzLnNuYXBzaG90LnBhdXNlUmVhc29ucy5sZW5ndGh8fGVsYXBzZWQ+MTAwPzA6ZGVsdGE7XG4gIGNvbnN0IHBsYXllclJldmlzaW9uPXRoaXMucGxheWVyLnZpc3VhbFJldmlzaW9uLG5wY1JldmlzaW9uPXRoaXMubnBjLnZpc3VhbFJldmlzaW9uO1xuICB0aGlzLnBsYXllci51cGRhdGUoZi5wbGF5ZXIsdGhpcy5zbmFwc2hvdC50YXNrPT09J2Nob3AnLG1vdGlvbkRlbHRhKTt0aGlzLm5wYy51cGRhdGUoZi5ucGMsZmFsc2UsbW90aW9uRGVsdGEpO1xuICBpZih0aGlzLnBsYXllci52aXN1YWxSZXZpc2lvbiE9PXBsYXllclJldmlzaW9ufHx0aGlzLm5wYy52aXN1YWxSZXZpc2lvbiE9PW5wY1JldmlzaW9uKXtcbiAgIHRoaXMuZGlydHk9dHJ1ZTtpZih0aGlzLnNhbXBsZSl0aGlzLnBhcmVudC5kYXRhc2V0Lm1vdGlvblJldmlzaW9uPVN0cmluZyh0aGlzLnBsYXllci52aXN1YWxSZXZpc2lvbj8/MCk7XG4gIH1cbiAgdGhpcy5jaG9yZW9ncmFwaHkuc2V0SGFuZEFuY2hvcih0aGlzLnBsYXllci5oYW5kUG9zaXRpb24oKSk7Zj10aGlzLmNob3Jlb2dyYXBoeS5mcmFtZTtcbiAgY29uc3Qgc3RhdGU9dGhpcy5zbmFwc2hvdCxob21lPXN0YXRlLnBoYXNlPT09J2hvbWUnfHxzdGF0ZS5waGFzZT09PSdzZXR1cCc7XG4gIGNvbnN0IHBoYXNlPWhvbWU/J2hvbWUnOmAke3N0YXRlLnRhc2t9YDtcbiAgaWYodGhpcy5sYXN0UGhhc2UhPT1waGFzZSl7XG4gICB0aGlzLmxhc3RQaGFzZT1waGFzZTt0aGlzLm92ZXJ2aWV3PWhvbWU7Y29uc3Qgb2Zmc2V0PXRoaXMuY2FtZXJhLnBvc2l0aW9uLmNsb25lKCkuc3ViKHRoaXMuY29udHJvbHMudGFyZ2V0KTtcbiAgIHRoaXMuY29udHJvbHMudGFyZ2V0LnNldChob21lPyh0aGlzLnNhbXBsZT8tMi41OjE0KTpzdGF0ZS50YXNrPT09J2NhcnJ5Jz9mLmNhcnQueDpmLnBsYXllci5wb3NpdGlvbi54LGhvbWU/KHRoaXMuc2FtcGxlPzEuMjowKToxLGhvbWU/KHRoaXMuc2FtcGxlPy01OjApOnN0YXRlLnRhc2s9PT0nY2FycnknP2YuY2FydC56OmYucGxheWVyLnBvc2l0aW9uLnopO1xuICAgaWYoaG9tZSl7aWYodGhpcy5zYW1wbGUpdGhpcy5jYW1lcmEucG9zaXRpb24uc2V0KDgsNS41LDEyKTtlbHNlIHRoaXMuY2FtZXJhLnBvc2l0aW9uLnNldCg0Myw0Miw1Nyk7fWVsc2UgdGhpcy5jYW1lcmEucG9zaXRpb24uY29weSh0aGlzLmNvbnRyb2xzLnRhcmdldCkuYWRkKG9mZnNldC5zZXRMZW5ndGgoc3RhdGUudGFzaz09PSdjYXJyeSc/MTM6c3RhdGUudGFzaz09PSdsb2FkJz8xMToxMikpO3RoaXMuZGlydHk9dHJ1ZTtcbiAgfVxuICBpZighaG9tZSYmIXRoaXMub3ZlcnZpZXcmJiFzdGF0ZS5wYXVzZVJlYXNvbnMubGVuZ3RoKXtjb25zdCB0YXJnZXQ9bmV3IFQuVmVjdG9yMyhzdGF0ZS50YXNrPT09J2NhcnJ5Jz9mLmNhcnQueDpmLnBsYXllci5wb3NpdGlvbi54LDEsc3RhdGUudGFzaz09PSdjYXJyeSc/Zi5jYXJ0Lno6Zi5wbGF5ZXIucG9zaXRpb24ueik7Y29uc3Qgc2hpZnQ9dGFyZ2V0LnN1Yih0aGlzLmNvbnRyb2xzLnRhcmdldCkubXVsdGlwbHlTY2FsYXIoLjA5KTtpZihzaGlmdC5sZW5ndGgoKT4uMDAyKXt0aGlzLmNvbnRyb2xzLnRhcmdldC5hZGQoc2hpZnQpO3RoaXMuY2FtZXJhLnBvc2l0aW9uLmFkZChzaGlmdCk7dGhpcy5kaXJ0eT10cnVlO319XG4gIHRoaXMuY29udHJvbHMudXBkYXRlKCk7XG4gIGNvbnN0IHBhaW50PUpTT04uc3RyaW5naWZ5KGYpO2lmKHBhaW50IT09dGhpcy5sYXN0UGFpbnQpe1xuICAgdGhpcy5sYXN0UGFpbnQ9cGFpbnQ7dGhpcy5kaXJ0eT10cnVlO3RoaXMuY2FydC5yb290LnBvc2l0aW9uLnNldChmLmNhcnQueCxmLmNhcnQueSxmLmNhcnQueik7XG4gICBmb3IoY29uc3Qgd2hlZWwgb2YgdGhpcy5jYXJ0LndoZWVscyl3aGVlbC5yb3RhdGlvbi56PS1mLmNhcnQueC8uMzU7XG4gICBmb3IobGV0IGk9MDtpPHRoaXMuY2FydC5yb3Blcy5sZW5ndGg7aSsrKXRoaXMuY2FydC5yb3Blc1tpXS52aXNpYmxlPWYucm9wZVByb2dyZXNzPihpL3RoaXMuY2FydC5yb3Blcy5sZW5ndGgpO1xuICAgZi50cmVlcy5mb3JFYWNoKCh0LGkpPT57XG4gICAgY29uc3QgdHJlZT10aGlzLnRyZWVzW2ldO3RyZWUucm9vdC5wb3NpdGlvbi5zZXQodC5wb3NpdGlvbi54LHQucG9zaXRpb24ueSx0LnBvc2l0aW9uLnopO3RyZWUudHJ1bmsudmlzaWJsZT0hdC5mZWxsZWQ7XG4gICAgdHJlZS5jcm93bi52aXNpYmxlPSF0LmZlbGxlZHx8dC5mYWxsUHJvZ3Jlc3M8Ljg7dHJlZS5jcm93bi5yb3RhdGlvbi56PXQuZmVsbGVkPy1NYXRoLlBJLzIqdC5mYWxsUHJvZ3Jlc3M6MDtcbiAgICB0cmVlLmNyb3duLnNjYWxlLnNldFNjYWxhcih0LmZlbGxlZD8xLXQuZmFsbFByb2dyZXNzKi41OjEpO1xuICAgfSk7XG4gICB3aGlsZSh0aGlzLmxvZ3MubGVuZ3RoPGYubG9ncy5sZW5ndGgpe2NvbnN0IGxvZz10aGlzLnBhbGV0dGU/bWFrZU5wckxvZyh0aGlzLnJlc291cmNlcyx0aGlzLnBhbGV0dGUpOm1ha2VMb2codGhpcy5yZXNvdXJjZXMpO3RoaXMuc2NlbmUuYWRkKGxvZyk7dGhpcy5sb2dzLnB1c2gobG9nKTt9XG4gICB0aGlzLmxvZ3MuZm9yRWFjaCgobG9nLGkpPT57Y29uc3QgaXRlbT1mLmxvZ3NbaV07bG9nLnZpc2libGU9ISFpdGVtO2lmKCFpdGVtKXJldHVybjtjb25zdCBwPWl0ZW0ucG9zaXRpb247bG9nLnBvc2l0aW9uLnNldChwLngscC55LHAueik7bG9nLnJvdGF0aW9uLnNldChpdGVtLnJvdGF0aW9uLGl0ZW0ubG9jYXRpb249PT0naGFuZCc/Zi5wbGF5ZXIueWF3Ok1hdGguUEkvMiwwKTt9KTtcbiAgIGNvbnN0IGhpdD1mLmVmZmVjdHMuZmluZChlPT5lLmtpbmQ9PT0naW1wYWN0JyYmZS5pbmRleD49MCksaGl0VHJlZT1oaXQ/Zi50cmVlc1toaXQuaW5kZXhdOm51bGw7XG4gICB0aGlzLmNoaXBzLmZvckVhY2goKGNoaXAsaSk9PntjaGlwLnZpc2libGU9ISFoaXRUcmVlO2lmKCFoaXR8fCFoaXRUcmVlKXJldHVybjtjb25zdCBhPWkqTWF0aC5QSS80LHQ9aGl0LnByb2dyZXNzO2NoaXAucG9zaXRpb24uc2V0KGhpdFRyZWUucG9zaXRpb24ueCtNYXRoLmNvcyhhKSp0KjEuMSwxLjErTWF0aC5zaW4odCpNYXRoLlBJKSouNTUtdCouNSxoaXRUcmVlLnBvc2l0aW9uLnorTWF0aC5zaW4oYSkqdCoxLjEpO2NoaXAucm90YXRpb24uc2V0KHQqNCxhLHQqNSk7Y2hpcC5zY2FsZS5zZXRTY2FsYXIoMS10Ki43KTt9KTtcbiAgIHRoaXMucGFyZW50LmRhdGFzZXQucGFydGljbGVzPWhpdFRyZWU/JzgnOicwJztcbiAgIGNvbnN0IHZhbHVlcz17YWN0aW9uOmYuYWN0aW9uLGZhbGxlbjpTdHJpbmcoc3RhdGUuY2hvcHBlZFRyZWVzKSxlZmZlY3RzOmYuZWZmZWN0cy5tYXAoZT0+ZS5raW5kKS5qb2luKCcsJyksbnBjOnN0YXRlLnBoYXNlPT09J3Jlc3QnPyhzdGF0ZS50YXNrPT09J2xvYWQnPydnYXRoZXInOidzZWN1cmUnKTpzdGF0ZS5waGFzZT09PSdyZXN1bHRzJz8nY2VsZWJyYXRlJzpzdGF0ZS50YXNrPT09J2NhcnJ5Jz8nZ3VpZGUnOidpZGxlJyxpbnZlbnRvcnk6YCR7c3RhdGUuZ3JvdW5kTG9nc30vJHtzdGF0ZS5jYXJ0TG9nc30vJHtzdGF0ZS5kZWxpdmVyZWRMb2dzfWAsY2FydFBvc2l0aW9uOmAke2YuY2FydC54LnRvRml4ZWQoMyl9LCR7Zi5jYXJ0LnoudG9GaXhlZCgzKX1gLHdvcmxkTG9nczpTdHJpbmcoZi5sb2dzLmxlbmd0aCkscm9wZTpmLnJvcGVQcm9ncmVzcy50b0ZpeGVkKDMpLHBsYXllck1vZGU6Zi5wbGF5ZXIubW9kZX07XG4gICBmb3IoY29uc3Rba2V5LHZhbHVlXW9mIE9iamVjdC5lbnRyaWVzKHZhbHVlcykpaWYodGhpcy5wYXJlbnQuZGF0YXNldFtrZXldIT09dmFsdWUpdGhpcy5wYXJlbnQuZGF0YXNldFtrZXldPXZhbHVlO1xuICAgdGhpcy5wYXJlbnQuc2V0QXR0cmlidXRlKCdhcmlhLWxhYmVsJyxg5Y+v5peL6L2s5LiJ57u05Yac5Zy644CC5Zyw6Z2iJHtzdGF0ZS5ncm91bmRMb2dzfeOAgei9puS4iiR7c3RhdGUuY2FydExvZ3N944CB5Yiw5a62JHtzdGF0ZS5kZWxpdmVyZWRMb2dzfeOAgiR7c3RhdGUucGF1c2VSZWFzb25zLmxlbmd0aD8n5bey5pqC5YGcJzonJ31gKTtcbiAgfVxuICBpZih0aGlzLmRpcnR5KXtcbiAgIHRoaXMucmVuZGVyZXIucmVuZGVyKHRoaXMuc2NlbmUsdGhpcy5jYW1lcmEpO3RoaXMuZGlydHk9ZmFsc2U7dGhpcy5wYWludGVkTGFzdEZyYW1lPXRydWU7XG4gICBpZih0aGlzLnNhbXBsZSl0aGlzLnBhcmVudC5kYXRhc2V0LmhhbmQ9dGhpcy5wbGF5ZXIuaGFuZFBvc2l0aW9uKCkudG9BcnJheSgpLm1hcChuPT5uLnRvRml4ZWQoNCkpLmpvaW4oJywnKTtcbiAgIHRoaXMucGFyZW50LmRhdGFzZXQuY2FtZXJhPXRoaXMuY2FtZXJhLnBvc2l0aW9uLnRvQXJyYXkoKS5tYXAobj0+bi50b0ZpeGVkKDMpKS5qb2luKCcsJyk7XG4gICBjb25zdCBwcm9qZWN0ZWQ9bmV3IFQuVmVjdG9yMygtNiwxLDEpLnByb2plY3QodGhpcy5jYW1lcmEpO3RoaXMucGFyZW50LmRhdGFzZXQucHJvYmU9cHJvamVjdGVkLnRvQXJyYXkoKS5tYXAobj0+bi50b0ZpeGVkKDQpKS5qb2luKCcsJyk7XG4gIH1cbiB9O1xuIHJvdGF0ZShkaXJlY3Rpb246bnVtYmVyKTp2b2lke2lmKCF0aGlzLmNvbnRyb2xzLmVuYWJsZWR8fHRoaXMuZGlzcG9zZWQpcmV0dXJuO2NvbnN0IG9mZnNldD10aGlzLmNhbWVyYS5wb3NpdGlvbi5jbG9uZSgpLnN1Yih0aGlzLmNvbnRyb2xzLnRhcmdldCk7b2Zmc2V0LmFwcGx5QXhpc0FuZ2xlKG5ldyBULlZlY3RvcjMoMCwxLDApLGRpcmVjdGlvbiouMjUpO3RoaXMuY2FtZXJhLnBvc2l0aW9uLmNvcHkodGhpcy5jb250cm9scy50YXJnZXQpLmFkZChvZmZzZXQpO3RoaXMuY29udHJvbHMudXBkYXRlKCk7dGhpcy5kaXJ0eT10cnVlO31cbiByZXNldFZpZXcoKTp2b2lke2lmKHRoaXMuZGlzcG9zZWQpcmV0dXJuO3RoaXMub3ZlcnZpZXc9dHJ1ZTt0aGlzLmNvbnRyb2xzLnJlc2V0KCk7dGhpcy5kaXJ0eT10cnVlO31cbiBzZXRJbnRlcmFjdGlvbkVuYWJsZWQoZW5hYmxlZDpib29sZWFuKTp2b2lke3RoaXMuY29udHJvbHMuZW5hYmxlZD1lbmFibGVkJiYhdGhpcy5sb3N0JiYhdGhpcy5kaXNwb3NlZDt9XG4gZGVzdHJveShyZW1vdmVDYW52YXM9dHJ1ZSk6dm9pZHtcbiAgaWYodGhpcy5kaXNwb3NlZClyZXR1cm47dGhpcy5kaXNwb3NlZD10cnVlO2NhbmNlbEFuaW1hdGlvbkZyYW1lKHRoaXMucmVxdWVzdCk7dGhpcy5ldmVudHMuYWJvcnQoKTt0aGlzLnJlc2l6ZU9ic2VydmVyPy5kaXNjb25uZWN0KCk7dGhpcy5zdWJzY3JpcHRpb25zLmZvckVhY2goc3RvcD0+c3RvcCgpKTtcbiAgdGhpcy5jb250cm9scz8uZGlzcG9zZSgpO3RoaXMuY2hvcmVvZ3JhcGh5LmRpc3Bvc2UoKTt0aGlzLnVzZXJIb3VzZT8uZGlzcG9zZSgpO3RoaXMudXNlckNoYXJhY3Rlcj8uZGlzcG9zZSgpO3RoaXMuc2NlbmUudHJhdmVyc2Uobz0+e2lmKG8gaW5zdGFuY2VvZiBULkluc3RhbmNlZE1lc2gpby5kaXNwb3NlKCk7fSk7dGhpcy5zdW4/LnNoYWRvdy5kaXNwb3NlKCk7dGhpcy5zY2VuZS5jbGVhcigpO3RoaXMucmVzb3VyY2VzLmRpc3Bvc2UoKTt0aGlzLnJlbmRlcmVyPy5kaXNwb3NlKCk7dGhpcy5yZW5kZXJlcj8uZm9yY2VDb250ZXh0TG9zcygpO1xuICBpZihyZW1vdmVDYW52YXMpdGhpcy5yZW5kZXJlcj8uZG9tRWxlbWVudC5yZW1vdmUoKTt0aGlzLnNhbXBsZUJhZGdlPy5yZW1vdmUoKTt0aGlzLmxvZ3M9W107dGhpcy5jaGlwcz1bXTt0aGlzLnBhcmVudC5kYXRhc2V0LmRpc3Bvc2VkPSd0cnVlJztcbiB9XG59XG4iXX0=