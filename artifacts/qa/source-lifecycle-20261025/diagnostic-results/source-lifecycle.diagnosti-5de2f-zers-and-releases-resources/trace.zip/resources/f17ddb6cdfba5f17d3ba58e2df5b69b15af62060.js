import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "e2e", "PROD": false, "SSR": false};export class PoseWorkerClient {
	factory;
	bitmap;
	baseUrl;
	worker = null;
	epoch = 0;
	nextId = 0;
	pending = null;
	ready = false;
	rejectStart = null;
	initTimer;
	frameTimer;
	constructor(factory = () => new Worker(new URL("worker/pose.js", this.baseUrl)), bitmap = (video) => createImageBitmap(video), baseUrl = new URL(import.meta.env.BASE_URL, location.href).href) {
		this.factory = factory;
		this.bitmap = bitmap;
		this.baseUrl = baseUrl;
	}
	async start(onFrame, onError = () => {}) {
		const stopping = this.stop();
		const epoch = this.epoch;
		await stopping;
		if (epoch !== this.epoch) throw new DOMException("Cancelled", "AbortError");
		const worker = this.factory();
		this.worker = worker;
		return new Promise((resolve, reject) => {
			this.rejectStart = reject;
			const fail = (message) => {
				if (epoch !== this.epoch) return;
				reject(new Error(message));
				this.rejectStart = null;
				void this.stop();
				onError(message);
			};
			this.initTimer = setTimeout(() => fail("模型初始化超时（30 秒），请重试"), 3e4);
			worker.onerror = () => fail("推理 Worker 失败，请重试或选择键盘演示");
			worker.onmessage = ({ data }) => {
				if (epoch !== this.epoch || data.kind === "disposed" || data.sourceEpoch !== epoch) return;
				if (data.kind === "ready") {
					clearTimeout(this.initTimer);
					this.ready = true;
					this.rejectStart = null;
					resolve();
				} else if (data.kind === "error") fail(data.message);
				else if (data.kind === "frame" && this.pending?.id === data.requestId && data.frame.capturedAtMs === this.pending.capturedAtMs) {
					clearTimeout(this.frameTimer);
					this.pending = null;
					onFrame(data.frame);
				}
			};
			worker.postMessage({
				kind: "init",
				sourceEpoch: epoch,
				baseUrl: this.baseUrl
			});
		});
	}
	submit(video, capturedAtMs) {
		const worker = this.worker, epoch = this.epoch;
		if (!worker || !this.ready || this.pending || video.readyState < 2 || !Number.isFinite(capturedAtMs)) return;
		const requestId = ++this.nextId;
		this.pending = {
			id: requestId,
			capturedAtMs
		};
		this.frameTimer = setTimeout(() => {
			if (epoch === this.epoch) worker.onmessage?.({ data: {
				kind: "error",
				sourceEpoch: epoch,
				message: "推理超时，请重试"
			} });
		}, 1e4);
		void this.bitmap(video).then((bitmap) => {
			if (epoch !== this.epoch) {
				bitmap.close();
				return;
			}
			try {
				worker.postMessage({
					kind: "frame",
					sourceEpoch: epoch,
					requestId,
					capturedAtMs,
					width: video.videoWidth,
					height: video.videoHeight,
					bitmap
				}, [bitmap]);
			} catch (error) {
				bitmap.close();
				throw error;
			}
		}).catch((error) => {
			if (epoch === this.epoch) worker.onmessage?.({ data: {
				kind: "error",
				sourceEpoch: epoch,
				message: `视频帧读取失败：${String(error)}`
			} });
		});
	}
	async stop() {
		this.epoch++;
		this.ready = false;
		this.pending = null;
		clearTimeout(this.initTimer);
		clearTimeout(this.frameTimer);
		this.rejectStart?.(new DOMException("Cancelled", "AbortError"));
		this.rejectStart = null;
		const worker = this.worker;
		this.worker = null;
		if (!worker) return;
		await new Promise((resolve) => {
			let done = false;
			const finish = () => {
				if (done) return;
				done = true;
				clearTimeout(timer);
				worker.onmessage = null;
				worker.onerror = null;
				worker.terminate();
				resolve();
			};
			const timer = setTimeout(finish, 300);
			worker.onmessage = ({ data }) => {
				if (data.kind === "disposed") finish();
			};
			worker.onerror = finish;
			try {
				worker.postMessage({ kind: "dispose" });
			} catch {
				finish();
			}
		});
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBT0EsT0FBTyxNQUFNLGlCQUFpQjtDQVVUO0NBQ0E7Q0FDQTtDQVhuQixBQUFRLFNBQTRCO0NBQ3BDLEFBQVEsUUFBUTtDQUNoQixBQUFRLFNBQVM7Q0FDakIsQUFBUSxVQUF1RDtDQUMvRCxBQUFRLFFBQVE7Q0FDaEIsQUFBUSxjQUErQztDQUN2RCxBQUFRO0NBQ1IsQUFBUTtDQUNSLFlBQ0UsQUFBaUIsZ0JBQWtDLElBQUksT0FBTyxJQUFJLElBQUksa0JBQWtCLEtBQUssT0FBTyxDQUFDLEdBQ3JHLEFBQWlCLFVBQVUsVUFBNEIsa0JBQWtCLEtBQUssR0FDOUUsQUFBaUIsVUFBVSxJQUFJLElBQUksWUFBWSxJQUFJLFVBQVUsU0FBUyxJQUFJLENBQUMsQ0FBQyxNQUM1RTtFQUhpQjtFQUNBO0VBQ0E7Q0FDaEI7Q0FDSCxNQUFNLE1BQU0sU0FBcUMsZ0JBQTJDLENBQUMsR0FBa0I7RUFDN0csTUFBTSxXQUFXLEtBQUssS0FBSztFQUMzQixNQUFNLFFBQVEsS0FBSztFQUNuQixNQUFNO0VBQ04sSUFBSSxVQUFVLEtBQUssT0FBTyxNQUFNLElBQUksYUFBYSxhQUFhLFlBQVk7RUFDMUUsTUFBTSxTQUFTLEtBQUssUUFBUTtFQUFHLEtBQUssU0FBUztFQUM3QyxPQUFPLElBQUksU0FBZSxTQUFTLFdBQVc7R0FDNUMsS0FBSyxjQUFjO0dBQ25CLE1BQU0sUUFBUSxZQUEwQjtJQUN0QyxJQUFJLFVBQVUsS0FBSyxPQUFPO0lBQzFCLE9BQU8sSUFBSSxNQUFNLE9BQU8sQ0FBQztJQUFHLEtBQUssY0FBYztJQUMvQyxLQUFLLEtBQUssS0FBSztJQUFHLFFBQVEsT0FBTztHQUNuQztHQUNBLEtBQUssWUFBWSxpQkFBaUIsS0FBSyxtQkFBbUIsR0FBRyxHQUFNO0dBQ25FLE9BQU8sZ0JBQWdCLEtBQUsseUJBQXlCO0dBQ3JELE9BQU8sYUFBYSxFQUFFLFdBQVc7SUFDL0IsSUFBSSxVQUFVLEtBQUssU0FBUyxLQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixPQUFPO0lBQ3BGLElBQUksS0FBSyxTQUFTLFNBQVM7S0FDekIsYUFBYSxLQUFLLFNBQVM7S0FBRyxLQUFLLFFBQVE7S0FBTSxLQUFLLGNBQWM7S0FBTSxRQUFRO0lBQ3BGLE9BQU8sSUFBSSxLQUFLLFNBQVMsU0FBUyxLQUFLLEtBQUssT0FBTztTQUM5QyxJQUFJLEtBQUssU0FBUyxXQUFXLEtBQUssU0FBUyxPQUFPLEtBQUssYUFBYSxLQUFLLE1BQU0saUJBQWlCLEtBQUssUUFBUSxjQUFjO0tBQzlILGFBQWEsS0FBSyxVQUFVO0tBQUcsS0FBSyxVQUFVO0tBQU0sUUFBUSxLQUFLLEtBQUs7SUFDeEU7R0FDRjtHQUNBLE9BQU8sWUFBWTtJQUFFLE1BQU07SUFBUSxhQUFhO0lBQU8sU0FBUyxLQUFLO0dBQVEsQ0FBQztFQUNoRixDQUFDO0NBQ0g7Q0FDQSxPQUFPLE9BQXlCLGNBQTRCO0VBQzFELE1BQU0sU0FBUyxLQUFLLFFBQVEsUUFBUSxLQUFLO0VBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxTQUFTLEtBQUssV0FBVyxNQUFNLGFBQWEsS0FBSyxDQUFDLE9BQU8sU0FBUyxZQUFZLEdBQUc7RUFDdEcsTUFBTSxZQUFZLEVBQUUsS0FBSztFQUN6QixLQUFLLFVBQVU7R0FBRSxJQUFJO0dBQVc7RUFBYTtFQUM3QyxLQUFLLGFBQWEsaUJBQWlCO0dBQ2pDLElBQUksVUFBVSxLQUFLLE9BQU8sT0FBTyxZQUFZLEVBQUUsTUFBTTtJQUFFLE1BQU07SUFBUyxhQUFhO0lBQU8sU0FBUztHQUFXLEVBQUUsQ0FBaUM7RUFDbkosR0FBRyxHQUFNO0VBQ1QsS0FBSyxLQUFLLE9BQU8sS0FBSyxDQUFDLENBQUMsTUFBSyxXQUFVO0dBQ3JDLElBQUksVUFBVSxLQUFLLE9BQU87SUFBRSxPQUFPLE1BQU07SUFBRztHQUFRO0dBQ3BELElBQUk7SUFDRixPQUFPLFlBQVk7S0FBRSxNQUFNO0tBQVMsYUFBYTtLQUFPO0tBQVc7S0FDakUsT0FBTyxNQUFNO0tBQVksUUFBUSxNQUFNO0tBQWE7SUFBTyxHQUFHLENBQUMsTUFBTSxDQUFDO0dBQzFFLFNBQVMsT0FBTztJQUNkLE9BQU8sTUFBTTtJQUFHLE1BQU07R0FDeEI7RUFDRixDQUFDLENBQUMsQ0FBQyxPQUFNLFVBQVM7R0FDaEIsSUFBSSxVQUFVLEtBQUssT0FBTyxPQUFPLFlBQVksRUFBRSxNQUFNO0lBQUUsTUFBTTtJQUFTLGFBQWE7SUFBTyxTQUFTLFdBQVcsT0FBTyxLQUFLO0dBQUksRUFBRSxDQUFpQztFQUNuSyxDQUFDO0NBQ0g7Q0FDQSxNQUFNLE9BQXNCO0VBQzFCLEtBQUs7RUFBUyxLQUFLLFFBQVE7RUFBTyxLQUFLLFVBQVU7RUFDakQsYUFBYSxLQUFLLFNBQVM7RUFBRyxhQUFhLEtBQUssVUFBVTtFQUMxRCxLQUFLLGNBQWMsSUFBSSxhQUFhLGFBQWEsWUFBWSxDQUFDO0VBQUcsS0FBSyxjQUFjO0VBQ3BGLE1BQU0sU0FBUyxLQUFLO0VBQVEsS0FBSyxTQUFTO0VBQzFDLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxJQUFJLFNBQWMsWUFBVztHQUNqQyxJQUFJLE9BQU87R0FDWCxNQUFNLGVBQXFCO0lBQ3pCLElBQUksTUFBTTtJQUFRLE9BQU87SUFBTSxhQUFhLEtBQUs7SUFDakQsT0FBTyxZQUFZO0lBQU0sT0FBTyxVQUFVO0lBQU0sT0FBTyxVQUFVO0lBQUcsUUFBUTtHQUM5RTtHQUNBLE1BQU0sUUFBUSxXQUFXLFFBQVEsR0FBRztHQUNwQyxPQUFPLGFBQWEsRUFBRSxXQUFXO0lBQUUsSUFBSSxLQUFLLFNBQVMsWUFBWSxPQUFPO0dBQUc7R0FDM0UsT0FBTyxVQUFVO0dBQ2pCLElBQUk7SUFBRSxPQUFPLFlBQVksRUFBRSxNQUFNLFVBQVUsQ0FBQztHQUFHLFFBQ3pDO0lBQUUsT0FBTztHQUFHO0VBQ3BCLENBQUM7Q0FDSDtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInBvc2VXb3JrZXJDbGllbnQudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBQb3NlRnJhbWUsIFdvcmtlclJlcXVlc3QsIFdvcmtlclJlc3BvbnNlIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5leHBvcnQgaW50ZXJmYWNlIFdvcmtlclBvcnQge1xuICBvbm1lc3NhZ2U6ICgoZXZlbnQ6IE1lc3NhZ2VFdmVudDxXb3JrZXJSZXNwb25zZT4pID0+IHZvaWQpIHwgbnVsbDtcbiAgb25lcnJvcjogKChldmVudDogRXJyb3JFdmVudCkgPT4gdm9pZCkgfCBudWxsO1xuICBwb3N0TWVzc2FnZShtZXNzYWdlOiBXb3JrZXJSZXF1ZXN0LCB0cmFuc2Zlcj86IFRyYW5zZmVyYWJsZVtdKTogdm9pZDtcbiAgdGVybWluYXRlKCk6IHZvaWQ7XG59XG5leHBvcnQgY2xhc3MgUG9zZVdvcmtlckNsaWVudCB7XG4gIHByaXZhdGUgd29ya2VyOiBXb3JrZXJQb3J0IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgZXBvY2ggPSAwO1xuICBwcml2YXRlIG5leHRJZCA9IDA7XG4gIHByaXZhdGUgcGVuZGluZzogeyBpZDogbnVtYmVyOyBjYXB0dXJlZEF0TXM6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgcmVhZHkgPSBmYWxzZTtcbiAgcHJpdmF0ZSByZWplY3RTdGFydDogKChlcnJvcjogRXJyb3IpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgaW5pdFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBmcmFtZVRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZDtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByZWFkb25seSBmYWN0b3J5OiAoKSA9PiBXb3JrZXJQb3J0ID0gKCkgPT4gbmV3IFdvcmtlcihuZXcgVVJMKCd3b3JrZXIvcG9zZS5qcycsIHRoaXMuYmFzZVVybCkpLFxuICAgIHByaXZhdGUgcmVhZG9ubHkgYml0bWFwID0gKHZpZGVvOiBIVE1MVmlkZW9FbGVtZW50KSA9PiBjcmVhdGVJbWFnZUJpdG1hcCh2aWRlbyksXG4gICAgcHJpdmF0ZSByZWFkb25seSBiYXNlVXJsID0gbmV3IFVSTChpbXBvcnQubWV0YS5lbnYuQkFTRV9VUkwsIGxvY2F0aW9uLmhyZWYpLmhyZWYsXG4gICkge31cbiAgYXN5bmMgc3RhcnQob25GcmFtZTogKGZyYW1lOiBQb3NlRnJhbWUpID0+IHZvaWQsIG9uRXJyb3I6IChtZXNzYWdlOiBzdHJpbmcpID0+IHZvaWQgPSAoKSA9PiB7fSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHN0b3BwaW5nID0gdGhpcy5zdG9wKCk7XG4gICAgY29uc3QgZXBvY2ggPSB0aGlzLmVwb2NoO1xuICAgIGF3YWl0IHN0b3BwaW5nO1xuICAgIGlmIChlcG9jaCAhPT0gdGhpcy5lcG9jaCkgdGhyb3cgbmV3IERPTUV4Y2VwdGlvbignQ2FuY2VsbGVkJywgJ0Fib3J0RXJyb3InKTtcbiAgICBjb25zdCB3b3JrZXIgPSB0aGlzLmZhY3RvcnkoKTsgdGhpcy53b3JrZXIgPSB3b3JrZXI7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMucmVqZWN0U3RhcnQgPSByZWplY3Q7XG4gICAgICBjb25zdCBmYWlsID0gKG1lc3NhZ2U6IHN0cmluZyk6IHZvaWQgPT4ge1xuICAgICAgICBpZiAoZXBvY2ggIT09IHRoaXMuZXBvY2gpIHJldHVybjtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihtZXNzYWdlKSk7IHRoaXMucmVqZWN0U3RhcnQgPSBudWxsO1xuICAgICAgICB2b2lkIHRoaXMuc3RvcCgpOyBvbkVycm9yKG1lc3NhZ2UpO1xuICAgICAgfTtcbiAgICAgIHRoaXMuaW5pdFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBmYWlsKCfmqKHlnovliJ3lp4vljJbotoXml7bvvIgzMCDnp5LvvInvvIzor7fph43or5UnKSwgMzBfMDAwKTtcbiAgICAgIHdvcmtlci5vbmVycm9yID0gKCkgPT4gZmFpbCgn5o6o55CGIFdvcmtlciDlpLHotKXvvIzor7fph43or5XmiJbpgInmi6nplK7nm5jmvJTnpLonKTtcbiAgICAgIHdvcmtlci5vbm1lc3NhZ2UgPSAoeyBkYXRhIH0pID0+IHtcbiAgICAgICAgaWYgKGVwb2NoICE9PSB0aGlzLmVwb2NoIHx8IGRhdGEua2luZCA9PT0gJ2Rpc3Bvc2VkJyB8fCBkYXRhLnNvdXJjZUVwb2NoICE9PSBlcG9jaCkgcmV0dXJuO1xuICAgICAgICBpZiAoZGF0YS5raW5kID09PSAncmVhZHknKSB7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuaW5pdFRpbWVyKTsgdGhpcy5yZWFkeSA9IHRydWU7IHRoaXMucmVqZWN0U3RhcnQgPSBudWxsOyByZXNvbHZlKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoZGF0YS5raW5kID09PSAnZXJyb3InKSBmYWlsKGRhdGEubWVzc2FnZSk7XG4gICAgICAgIGVsc2UgaWYgKGRhdGEua2luZCA9PT0gJ2ZyYW1lJyAmJiB0aGlzLnBlbmRpbmc/LmlkID09PSBkYXRhLnJlcXVlc3RJZCAmJiBkYXRhLmZyYW1lLmNhcHR1cmVkQXRNcyA9PT0gdGhpcy5wZW5kaW5nLmNhcHR1cmVkQXRNcykge1xuICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmZyYW1lVGltZXIpOyB0aGlzLnBlbmRpbmcgPSBudWxsOyBvbkZyYW1lKGRhdGEuZnJhbWUpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgd29ya2VyLnBvc3RNZXNzYWdlKHsga2luZDogJ2luaXQnLCBzb3VyY2VFcG9jaDogZXBvY2gsIGJhc2VVcmw6IHRoaXMuYmFzZVVybCB9KTtcbiAgICB9KTtcbiAgfVxuICBzdWJtaXQodmlkZW86IEhUTUxWaWRlb0VsZW1lbnQsIGNhcHR1cmVkQXRNczogbnVtYmVyKTogdm9pZCB7XG4gICAgY29uc3Qgd29ya2VyID0gdGhpcy53b3JrZXIsIGVwb2NoID0gdGhpcy5lcG9jaDtcbiAgICBpZiAoIXdvcmtlciB8fCAhdGhpcy5yZWFkeSB8fCB0aGlzLnBlbmRpbmcgfHwgdmlkZW8ucmVhZHlTdGF0ZSA8IDIgfHwgIU51bWJlci5pc0Zpbml0ZShjYXB0dXJlZEF0TXMpKSByZXR1cm47XG4gICAgY29uc3QgcmVxdWVzdElkID0gKyt0aGlzLm5leHRJZDtcbiAgICB0aGlzLnBlbmRpbmcgPSB7IGlkOiByZXF1ZXN0SWQsIGNhcHR1cmVkQXRNcyB9O1xuICAgIHRoaXMuZnJhbWVUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKGVwb2NoID09PSB0aGlzLmVwb2NoKSB3b3JrZXIub25tZXNzYWdlPy4oeyBkYXRhOiB7IGtpbmQ6ICdlcnJvcicsIHNvdXJjZUVwb2NoOiBlcG9jaCwgbWVzc2FnZTogJ+aOqOeQhui2heaXtu+8jOivt+mHjeivlScgfSB9IGFzIE1lc3NhZ2VFdmVudDxXb3JrZXJSZXNwb25zZT4pO1xuICAgIH0sIDEwXzAwMCk7XG4gICAgdm9pZCB0aGlzLmJpdG1hcCh2aWRlbykudGhlbihiaXRtYXAgPT4ge1xuICAgICAgaWYgKGVwb2NoICE9PSB0aGlzLmVwb2NoKSB7IGJpdG1hcC5jbG9zZSgpOyByZXR1cm47IH1cbiAgICAgIHRyeSB7XG4gICAgICAgIHdvcmtlci5wb3N0TWVzc2FnZSh7IGtpbmQ6ICdmcmFtZScsIHNvdXJjZUVwb2NoOiBlcG9jaCwgcmVxdWVzdElkLCBjYXB0dXJlZEF0TXMsXG4gICAgICAgICAgd2lkdGg6IHZpZGVvLnZpZGVvV2lkdGgsIGhlaWdodDogdmlkZW8udmlkZW9IZWlnaHQsIGJpdG1hcCB9LCBbYml0bWFwXSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBiaXRtYXAuY2xvc2UoKTsgdGhyb3cgZXJyb3I7XG4gICAgICB9XG4gICAgfSkuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgaWYgKGVwb2NoID09PSB0aGlzLmVwb2NoKSB3b3JrZXIub25tZXNzYWdlPy4oeyBkYXRhOiB7IGtpbmQ6ICdlcnJvcicsIHNvdXJjZUVwb2NoOiBlcG9jaCwgbWVzc2FnZTogYOinhumikeW4p+ivu+WPluWksei0pe+8miR7U3RyaW5nKGVycm9yKX1gIH0gfSBhcyBNZXNzYWdlRXZlbnQ8V29ya2VyUmVzcG9uc2U+KTtcbiAgICB9KTtcbiAgfVxuICBhc3luYyBzdG9wKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRoaXMuZXBvY2grKzsgdGhpcy5yZWFkeSA9IGZhbHNlOyB0aGlzLnBlbmRpbmcgPSBudWxsO1xuICAgIGNsZWFyVGltZW91dCh0aGlzLmluaXRUaW1lcik7IGNsZWFyVGltZW91dCh0aGlzLmZyYW1lVGltZXIpO1xuICAgIHRoaXMucmVqZWN0U3RhcnQ/LihuZXcgRE9NRXhjZXB0aW9uKCdDYW5jZWxsZWQnLCAnQWJvcnRFcnJvcicpKTsgdGhpcy5yZWplY3RTdGFydCA9IG51bGw7XG4gICAgY29uc3Qgd29ya2VyID0gdGhpcy53b3JrZXI7IHRoaXMud29ya2VyID0gbnVsbDtcbiAgICBpZiAoIXdvcmtlcikgcmV0dXJuO1xuICAgIGF3YWl0IG5ldyBQcm9taXNlPHZvaWQ+KHJlc29sdmUgPT4ge1xuICAgICAgbGV0IGRvbmUgPSBmYWxzZTtcbiAgICAgIGNvbnN0IGZpbmlzaCA9ICgpOiB2b2lkID0+IHtcbiAgICAgICAgaWYgKGRvbmUpIHJldHVybjsgZG9uZSA9IHRydWU7IGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICAgIHdvcmtlci5vbm1lc3NhZ2UgPSBudWxsOyB3b3JrZXIub25lcnJvciA9IG51bGw7IHdvcmtlci50ZXJtaW5hdGUoKTsgcmVzb2x2ZSgpO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dChmaW5pc2gsIDMwMCk7XG4gICAgICB3b3JrZXIub25tZXNzYWdlID0gKHsgZGF0YSB9KSA9PiB7IGlmIChkYXRhLmtpbmQgPT09ICdkaXNwb3NlZCcpIGZpbmlzaCgpOyB9O1xuICAgICAgd29ya2VyLm9uZXJyb3IgPSBmaW5pc2g7XG4gICAgICB0cnkgeyB3b3JrZXIucG9zdE1lc3NhZ2UoeyBraW5kOiAnZGlzcG9zZScgfSk7IH1cbiAgICAgIGNhdGNoIHsgZmluaXNoKCk7IH1cbiAgICB9KTtcbiAgfVxufVxuIl19