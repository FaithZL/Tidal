import {test,expect} from '../helpers/manualModeTest.js';

test.use({channel:'chromium',baseURL:'http://127.0.0.1:4174'});
test('the pre-training tutorial explains all three movements without starting a session or camera',async({page})=>{
 await page.addInitScript(()=>{navigator.mediaDevices.getUserMedia=async()=>{throw new Error('Tutorial must not request a camera');};});
 await page.goto('/?e2e=1&art=npr-sample');
 await page.getByRole('button',{name:'先看动作教学',exact:true}).click();
 const dialog=page.getByRole('dialog',{name:'动作教学',exact:true});await expect(dialog).toBeVisible();
 await expect(page.locator('#app')).toHaveAttribute('data-phase','home');
 for(const name of ['挥砍','装车','拉车持姿']){await dialog.getByRole('button',{name,exact:true}).click();await expect(dialog.locator('#tutorialStepList button')).not.toHaveCount(0);}
 await expect(page.locator('#chopValue')).toHaveText('0/15');await expect(page.locator('#loadValue')).toHaveText('0/15');
 await dialog.getByRole('button',{name:'关闭教学',exact:true}).click();await expect(page.locator('#planModal')).toBeVisible();
});
