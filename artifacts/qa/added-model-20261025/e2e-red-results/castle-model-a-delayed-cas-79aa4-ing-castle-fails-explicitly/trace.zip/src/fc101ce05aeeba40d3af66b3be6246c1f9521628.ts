import {test,expect} from '../helpers/manualModeTest.js';
test.use({channel:'chromium'});

test('the supplied castle is a real grounded mesh in the farm and local NPR scene',async({page})=>{
 const errors:string[]=[],external:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 page.on('request',r=>{if(!['http://127.0.0.1:4173','null'].includes(new URL(r.url()).origin))external.push(r.url());});
 for(const url of ['/', '/?art=npr-sample']){
  const response=page.waitForResponse(r=>r.url().endsWith('/assets/user-models/castle.fbx'));
  await page.goto(url);expect((await response).status()).toBe(200);
  await expect(page.locator('#worldCanvas')).toHaveAttribute('data-assets','ready');
  await expect(page.locator('#worldCanvas')).toHaveAttribute('data-castle','user-fbx');
  await expect(page.locator('#worldCanvas')).toHaveAttribute('data-castle-triangles','60000');
  await expect(page.locator('#worldCanvas')).toHaveAttribute('data-castle-position','-10.000,0.025,-29.000');
  await expect(page.locator('#worldCanvas')).toHaveAttribute('data-inventory','0/0/0');
  const before=await page.locator('#worldCanvas').getAttribute('data-camera');await page.locator('#viewLeft').click();
  await expect(page.locator('#worldCanvas')).not.toHaveAttribute('data-camera',before!);
  await expect(page.locator('#chopValue')).toHaveText('0/15');
 }
 expect(errors).toEqual([]);expect(external).toEqual([]);
});

test('a delayed castle keeps the farm start gate closed and a missing castle fails explicitly',async({page})=>{
 let release=()=>{};const gate=new Promise<void>(resolve=>{release=resolve;});
 await page.route('**/assets/user-models/castle.fbx',async route=>{await gate;await route.fulfill({status:404,body:'missing fixture'});});
 await page.goto('/',{waitUntil:'domcontentloaded'});
 try{await expect(page.locator('#acceptPlan')).toBeDisabled();await expect(page.locator('#worldCanvas')).toHaveAttribute('data-assets','loading');}finally{release();}
 await expect(page.locator('#renderError')).toContainText('用户城堡模型加载失败');
 await expect(page.locator('#worldCanvas')).toHaveAttribute('data-assets','failed');
 await expect(page.locator('#acceptPlan')).toBeDisabled();await expect(page.locator('#chopValue')).toHaveText('0/15');
});
